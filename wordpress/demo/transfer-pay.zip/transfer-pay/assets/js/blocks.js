/**
 * Registers the Transfer Pay methods with the Checkout block. Plain ES5, no build step.
 */
( function () {
	var registry = window.wc && window.wc.wcBlocksRegistry;
	var settings = window.wc && window.wc.wcSettings;
	if ( ! registry || ! settings ) {
		return;
	}

	var el = window.wp.element.createElement;
	var decode = window.wp.htmlEntities.decodeEntities;

	[ 'tp_gcash', 'tp_maya', 'tp_bank' ].forEach( function ( id ) {
		var data = settings.getSetting( id + '_data', null );
		if ( ! data ) {
			return;
		}

		var title = decode( data.title || '' );

		var Content = function () {
			return el( 'div', { className: 'tp-blocks-description' }, decode( data.description || '' ) );
		};

		var Label = function ( props ) {
			var Text = props.components.PaymentMethodLabel;
			return el(
				'span',
				{ className: 'tp-blocks-label' },
				data.icon ? el( 'img', { src: data.icon, alt: '', width: 24, height: 24, style: { marginInlineEnd: '0.5em', verticalAlign: 'middle' } } ) : null,
				el( Text, { text: title } )
			);
		};

		registry.registerPaymentMethod( {
			name: id,
			label: el( Label ),
			content: el( Content ),
			edit: el( Content ),
			canMakePayment: function () {
				return true;
			},
			ariaLabel: title,
			supports: { features: data.supports || [ 'products' ] },
		} );
	} );
}() );
