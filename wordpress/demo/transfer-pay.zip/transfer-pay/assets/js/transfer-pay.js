/**
 * One-tap copy buttons for the "How to pay" panel.
 */
( function () {
	var panel = document.getElementById( 'tp-panel' );
	if ( ! panel ) {
		return;
	}

	var live = panel.querySelector( '[data-tp-live]' );

	function announce( message ) {
		// Clear first so repeating the same message is announced again.
		live.textContent = '';
		window.setTimeout( function () {
			live.textContent = message;
		}, 50 );
	}

	function legacyCopy( text ) {
		var area = document.createElement( 'textarea' );
		var ok = false;
		area.value = text;
		area.setAttribute( 'readonly', '' );
		area.style.position = 'fixed';
		area.style.opacity = '0';
		document.body.appendChild( area );
		area.select();
		try {
			ok = document.execCommand( 'copy' );
		} catch ( e ) {
			ok = false;
		}
		document.body.removeChild( area );
		return ok;
	}

	function copy( text ) {
		if ( navigator.clipboard && window.isSecureContext ) {
			return navigator.clipboard.writeText( text ).then(
				function () {
					return true;
				},
				function () {
					return legacyCopy( text );
				}
			);
		}
		return Promise.resolve( legacyCopy( text ) );
	}

	panel.addEventListener( 'click', function ( event ) {
		var button = event.target.closest( '[data-tp-copy]' );
		if ( ! button ) {
			return;
		}

		copy( button.getAttribute( 'data-tp-copy' ) ).then( function ( ok ) {
			var text = button.querySelector( '.tp-copy__text' );

			if ( ! ok ) {
				announce( panel.getAttribute( 'data-tp-failed' ) );
				return;
			}

			announce( panel.getAttribute( 'data-tp-copied' ).replace( '%s', button.getAttribute( 'data-tp-label' ) ) );
			if ( ! text.hasAttribute( 'data-original' ) ) {
				text.setAttribute( 'data-original', text.textContent );
			}
			button.classList.add( 'is-copied' );
			text.textContent = panel.getAttribute( 'data-tp-done' );
			window.clearTimeout( button.tpTimer );
			button.tpTimer = window.setTimeout( function () {
				button.classList.remove( 'is-copied' );
				text.textContent = text.getAttribute( 'data-original' );
			}, 2000 );
		} );
	} );

	// After an upload redirect, move focus to the result so it is read out.
	var result = panel.querySelector( '[data-tp-focus]' );
	if ( result ) {
		result.focus();
	}
}() );
