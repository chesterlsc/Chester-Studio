<?php
/**
 * Order screen: proof meta box with Verify and Reject.
 *
 * @package Transfer_Pay
 */

defined( 'ABSPATH' ) || exit;

/**
 * Lets shop staff check a proof and settle the order.
 */
final class Transfer_Pay_Admin {

	/**
	 * Order shown in the meta box on this screen; its action forms are printed in the footer.
	 *
	 * @var int
	 */
	private static $box_order_id = 0;

	/**
	 * Register admin hooks.
	 */
	public static function init() {
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_meta_box' ), 10, 2 );
		add_action( 'admin_footer', array( __CLASS__, 'print_action_forms' ) );
		add_action( 'admin_post_tp_verify', array( __CLASS__, 'handle_verify' ) );
		add_action( 'admin_post_tp_reject', array( __CLASS__, 'handle_reject' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'status_colours' ), 20 ); // After WooCommerce registers its admin styles.
	}

	/**
	 * Add the meta box to transfer orders (HPOS and legacy screens alike).
	 *
	 * @param string           $screen_id     Screen or post type.
	 * @param WP_Post|WC_Order $post_or_order Object being edited.
	 */
	public static function add_meta_box( $screen_id, $post_or_order = null ) {
		$order = $post_or_order instanceof WP_Post ? wc_get_order( $post_or_order->ID ) : $post_or_order;
		if ( ! Transfer_Pay::is_transfer_order( $order ) ) {
			return;
		}

		add_meta_box(
			'transfer-pay',
			__( 'Transfer payment', 'transfer-pay' ),
			array( __CLASS__, 'render_meta_box' ),
			wc_get_page_screen_id( 'shop-order' ),
			'side',
			'high'
		);
	}

	/**
	 * Meta box body.
	 *
	 * @param WP_Post|WC_Order $post_or_order Object being edited.
	 */
	public static function render_meta_box( $post_or_order ) {
		$order = $post_or_order instanceof WP_Post ? wc_get_order( $post_or_order->ID ) : $post_or_order;
		if ( ! Transfer_Pay::is_transfer_order( $order ) ) {
			return;
		}

		$path      = Transfer_Pay_Proof::get_proof_path( $order );
		$reference = (string) $order->get_meta( '_tp_reference' );
		$uploaded  = (int) $order->get_meta( '_tp_proof_uploaded_at' );
		$reason    = (string) $order->get_meta( '_tp_reject_reason' );
		$open      = $order->has_status( array( 'tp-awaiting', 'tp-review' ) );

		if ( $open ) {
			self::$box_order_id = $order->get_id();
		}
		?>
		<p><strong><?php esc_html_e( 'Method:', 'transfer-pay' ); ?></strong> <?php echo esc_html( $order->get_payment_method_title() ); ?></p>
		<p><strong><?php esc_html_e( 'Reference:', 'transfer-pay' ); ?></strong> <?php echo esc_html( '' !== $reference ? $reference : '–' ); ?></p>
		<?php if ( $uploaded ) : ?>
			<p><strong><?php esc_html_e( 'Uploaded:', 'transfer-pay' ); ?></strong> <?php echo esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $uploaded ) ); ?></p>
		<?php endif; ?>

		<?php if ( $path ) : ?>
			<?php $url = Transfer_Pay_Proof::get_view_url( $order ); ?>
			<?php if ( 'application/pdf' === $order->get_meta( '_tp_proof_mime' ) ) : ?>
				<p><a class="button" href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Open PDF proof', 'transfer-pay' ); ?></a></p>
			<?php else : ?>
				<p>
					<a href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener">
						<img src="<?php echo esc_url( $url ); ?>" alt="<?php /* translators: %s: order number. */ echo esc_attr( sprintf( __( 'Payment proof for order %s', 'transfer-pay' ), $order->get_order_number() ) ); ?>" style="display:block;max-width:100%;height:auto;border:1px solid #dcdcde;border-radius:4px;">
					</a>
				</p>
			<?php endif; ?>
		<?php elseif ( $open ) : ?>
			<p><?php esc_html_e( 'No proof uploaded yet.', 'transfer-pay' ); ?></p>
		<?php endif; ?>

		<?php if ( '' !== $reason && $order->has_status( 'tp-awaiting' ) ) : ?>
			<p><strong><?php esc_html_e( 'Last rejection:', 'transfer-pay' ); ?></strong> <?php echo esc_html( $reason ); ?></p>
		<?php endif; ?>

		<?php if ( $open ) : ?>
			<?php // Buttons belong to forms printed in the footer (form="…"), since forms cannot nest inside the order form. ?>
			<p><button type="submit" form="tp-verify-form" class="button button-primary"><?php esc_html_e( 'Verify payment', 'transfer-pay' ); ?></button></p>
			<?php if ( $order->has_status( 'tp-review' ) ) : ?>
				<p>
					<label for="tp-reject-reason"><?php esc_html_e( 'Reason for rejecting (sent to the shopper)', 'transfer-pay' ); ?></label>
					<textarea id="tp-reject-reason" name="reason" form="tp-reject-form" rows="3" class="widefat" required></textarea>
				</p>
				<p><button type="submit" form="tp-reject-form" class="button"><?php esc_html_e( 'Reject proof', 'transfer-pay' ); ?></button></p>
			<?php endif; ?>
		<?php endif; ?>
		<?php
	}

	/**
	 * Print the Verify and Reject forms outside the main order form.
	 */
	public static function print_action_forms() {
		if ( ! self::$box_order_id ) {
			return;
		}

		foreach ( array( 'tp_verify', 'tp_reject' ) as $action ) {
			?>
			<form id="<?php echo esc_attr( str_replace( '_', '-', $action ) ); ?>-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" hidden>
				<input type="hidden" name="action" value="<?php echo esc_attr( $action ); ?>">
				<input type="hidden" name="order_id" value="<?php echo esc_attr( self::$box_order_id ); ?>">
				<?php wp_nonce_field( $action . '_' . self::$box_order_id, 'tp_nonce', false ); ?>
			</form>
			<?php
		}
	}

	/**
	 * Request handler: Verify.
	 */
	public static function handle_verify() {
		$order = self::get_requested_order( 'tp_verify' );
		self::verify_order( $order );

		wp_safe_redirect( $order->get_edit_order_url() );
		exit;
	}

	/**
	 * Request handler: Reject.
	 */
	public static function handle_reject() {
		$order  = self::get_requested_order( 'tp_reject' );
		$reason = isset( $_POST['reason'] ) ? sanitize_textarea_field( wp_unslash( $_POST['reason'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Checked in get_requested_order().

		if ( '' === trim( $reason ) ) {
			wp_die( esc_html__( 'Please give the shopper a reason for rejecting the proof.', 'transfer-pay' ), '', array( 'response' => 400, 'back_link' => true ) );
		}

		self::reject_order( $order, $reason );

		wp_safe_redirect( $order->get_edit_order_url() );
		exit;
	}

	/**
	 * Check nonce and capability, and load the order an admin action targets.
	 *
	 * @param string $action Action name, also the nonce prefix.
	 * @return WC_Order
	 */
	private static function get_requested_order( $action ) {
		$order_id = isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified on the next line.
		check_admin_referer( $action . '_' . $order_id, 'tp_nonce' );

		if ( ! current_user_can( 'edit_shop_orders' ) ) {
			wp_die( esc_html__( 'You are not allowed to manage orders.', 'transfer-pay' ), '', array( 'response' => 403 ) );
		}

		$order = wc_get_order( $order_id );
		if ( ! Transfer_Pay::is_transfer_order( $order ) ) {
			wp_die( esc_html__( 'Order not found.', 'transfer-pay' ), '', array( 'response' => 404 ) );
		}

		return $order;
	}

	/**
	 * Mark the transfer as received: payment_complete() moves the order on and records the reference.
	 *
	 * @param WC_Order $order Order.
	 * @return bool
	 */
	public static function verify_order( WC_Order $order ) {
		if ( ! $order->has_status( array( 'tp-awaiting', 'tp-review' ) ) ) {
			return false;
		}

		/* translators: %s: name of the shop user who verified the payment. */
		$order->add_order_note( sprintf( __( 'Transfer verified by %s.', 'transfer-pay' ), self::current_user_name() ), 0, true );

		return $order->payment_complete( (string) $order->get_meta( '_tp_reference' ) );
	}

	/**
	 * Send the order back to "Awaiting transfer" and tell the shopper why.
	 *
	 * @param WC_Order $order  Order.
	 * @param string   $reason Reason shown to the shopper.
	 * @return bool
	 */
	public static function reject_order( WC_Order $order, $reason ) {
		$reason = trim( sanitize_textarea_field( $reason ) );
		if ( '' === $reason || ! $order->has_status( 'tp-review' ) ) {
			return false;
		}

		$order->update_meta_data( '_tp_reject_reason', $reason );
		/* translators: 1: name of the shop user, 2: reason given. */
		$order->set_status( 'tp-awaiting', sprintf( __( 'Payment proof rejected by %1$s: %2$s', 'transfer-pay' ), self::current_user_name(), $reason ) );
		$order->save();

		// Give the shopper a fresh window to pay.
		Transfer_Pay::schedule_expiry( $order );

		/**
		 * Fires after staff reject a payment proof. Sends the "Transfer not confirmed" email.
		 *
		 * @param int      $order_id Order ID.
		 * @param WC_Order $order    Order.
		 */
		do_action( 'transfer_pay_proof_rejected', $order->get_id(), $order );

		return true;
	}

	/**
	 * Status pill colours in the orders list.
	 */
	public static function status_colours() {
		wp_add_inline_style(
			'woocommerce_admin_styles',
			'.order-status.status-tp-awaiting{background:#f8dda7;color:#94660c}.order-status.status-tp-review{background:#c8d7e1;color:#2e4453}'
		);
	}

	/**
	 * Display name for order notes.
	 *
	 * @return string
	 */
	private static function current_user_name() {
		$user = wp_get_current_user();
		return $user->exists() ? $user->display_name : __( 'the system', 'transfer-pay' );
	}
}
