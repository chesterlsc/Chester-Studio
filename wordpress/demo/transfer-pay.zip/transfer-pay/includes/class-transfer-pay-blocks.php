<?php
/**
 * Cart and Checkout block integration, one instance per gateway.
 *
 * @package Transfer_Pay
 */

defined( 'ABSPATH' ) || exit;

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

/**
 * Exposes a Transfer Pay gateway to the Checkout block.
 */
final class Transfer_Pay_Blocks extends AbstractPaymentMethodType {

	/**
	 * The gateway this integration describes.
	 *
	 * @var Transfer_Pay_Gateway
	 */
	private $gateway;

	/**
	 * Constructor.
	 *
	 * @param Transfer_Pay_Gateway $gateway Gateway instance.
	 */
	public function __construct( Transfer_Pay_Gateway $gateway ) {
		$this->gateway = $gateway;
		$this->name    = $gateway->id;
	}

	/**
	 * Load settings.
	 */
	public function initialize() {
		$this->settings = $this->gateway->settings;
	}

	/**
	 * Whether the method can be offered.
	 *
	 * @return bool
	 */
	public function is_active() {
		return $this->gateway->is_available();
	}

	/**
	 * Script that registers all three methods (no build step).
	 *
	 * @return string[]
	 */
	public function get_payment_method_script_handles() {
		wp_register_script(
			'transfer-pay-blocks',
			TRANSFER_PAY_URL . 'assets/js/blocks.js',
			array( 'wc-blocks-registry', 'wc-settings', 'wp-element', 'wp-html-entities' ),
			TRANSFER_PAY_VERSION,
			true
		);

		return array( 'transfer-pay-blocks' );
	}

	/**
	 * Data exposed to the script as `getSetting( '{id}_data' )`.
	 *
	 * @return array
	 */
	public function get_payment_method_data() {
		return array(
			'title'       => $this->gateway->get_title(),
			'description' => $this->gateway->get_description(),
			'icon'        => $this->gateway->icon,
			'supports'    => array_values( array_filter( $this->gateway->supports, array( $this->gateway, 'supports' ) ) ),
		);
	}
}
