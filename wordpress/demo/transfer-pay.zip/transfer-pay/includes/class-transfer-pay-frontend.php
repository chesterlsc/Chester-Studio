<?php
/**
 * The shopper-facing "How to pay" panel on the thank-you and My Account order pages.
 *
 * @package Transfer_Pay
 */

defined( 'ABSPATH' ) || exit;

/**
 * Renders payment instructions and the proof upload form.
 */
final class Transfer_Pay_Frontend {

	/**
	 * Hook the panel into the order pages.
	 */
	public static function init() {
		foreach ( Transfer_Pay::gateway_ids() as $id ) {
			add_action( 'woocommerce_thankyou_' . $id, array( __CLASS__, 'render_panel' ) );
		}
		// Priority 5 puts it above the order details table.
		add_action( 'woocommerce_view_order', array( __CLASS__, 'render_panel' ), 5 );
	}

	/**
	 * Output the panel while the order is waiting for (or checking) a transfer.
	 *
	 * @param int $order_id Order ID.
	 */
	public static function render_panel( $order_id ) {
		$order   = wc_get_order( $order_id );
		$gateway = Transfer_Pay_Proof::accepts_proof( $order ) ? Transfer_Pay::get_gateway( $order ) : null;
		if ( ! $gateway ) {
			return;
		}

		wp_enqueue_style( 'transfer-pay', TRANSFER_PAY_URL . 'assets/css/transfer-pay.css', array(), TRANSFER_PAY_VERSION );
		wp_enqueue_script( 'transfer-pay', TRANSFER_PAY_URL . 'assets/js/transfer-pay.js', array(), TRANSFER_PAY_VERSION, true );

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Display-only result flag set by our own redirect.
		$flag = isset( $_GET['tp_proof'] ) ? sanitize_key( wp_unslash( $_GET['tp_proof'] ) ) : '';

		wc_get_template(
			'order/tp-payment-panel.php',
			array(
				'order'         => $order,
				'gateway'       => $gateway,
				'wallet'        => Transfer_Pay::wallet( $gateway->wallet ),
				'details'       => Transfer_Pay::get_payment_details( $order ),
				'error'         => self::error_message( $flag ),
				'just_uploaded' => 'uploaded' === $flag,
			),
			'',
			TRANSFER_PAY_PATH . 'templates/'
		);
	}

	/**
	 * Human message for an upload error flag.
	 *
	 * @param string $flag Result flag from the redirect.
	 * @return string Empty when there is nothing to report.
	 */
	private static function error_message( $flag ) {
		$messages = array(
			'no_file'       => __( 'Please choose a file to upload.', 'transfer-pay' ),
			'too_large'     => __( 'That file is larger than 5 MB. A screenshot is usually much smaller than a photo.', 'transfer-pay' ),
			'invalid_type'  => __( 'That file type is not accepted. Please upload a JPG, PNG, WebP or PDF.', 'transfer-pay' ),
			'upload_failed' => __( 'The upload did not go through. Please try again.', 'transfer-pay' ),
			'not_allowed'   => __( 'This order is no longer waiting for a payment proof.', 'transfer-pay' ),
		);

		return isset( $messages[ $flag ] ) ? $messages[ $flag ] : '';
	}
}
