<?php
/**
 * The payment gateway. One class, three instances: GCash, Maya and bank transfer.
 *
 * @package Transfer_Pay
 */

defined( 'ABSPATH' ) || exit;

/**
 * Manual transfer gateway with proof-of-payment upload.
 */
class Transfer_Pay_Gateway extends WC_Payment_Gateway {

	/**
	 * Wallet key: gcash, maya or bank.
	 *
	 * @var string
	 */
	public $wallet;

	/**
	 * Constructor.
	 *
	 * @param string $wallet Wallet key.
	 */
	public function __construct( $wallet ) {
		$labels = Transfer_Pay::wallet( $wallet );

		$this->wallet     = $wallet;
		$this->id         = 'tp_' . $wallet;
		$this->icon       = TRANSFER_PAY_URL . 'assets/img/' . $labels['icon'];
		$this->has_fields = false;
		/* translators: %s: payment method name, e.g. GCash. */
		$this->method_title       = sprintf( __( 'Transfer Pay: %s', 'transfer-pay' ), $labels['title'] );
		$this->method_description = __( 'Shoppers send the money themselves, then upload a screenshot of the receipt. You check it and verify the payment from the order screen.', 'transfer-pay' );
		$this->supports           = array( 'products' );

		$this->init_form_fields();
		$this->init_settings();

		$this->title       = $this->get_option( 'title' );
		$this->description = $this->get_option( 'description' );

		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
	}

	/**
	 * Settings fields, with defaults for this wallet.
	 */
	public function init_form_fields() {
		$labels = Transfer_Pay::wallet( $this->wallet );

		$this->form_fields = array(
			'enabled'        => array(
				'title'   => __( 'Enable/Disable', 'transfer-pay' ),
				'type'    => 'checkbox',
				/* translators: %s: payment method name, e.g. GCash. */
				'label'   => sprintf( __( 'Accept %s transfers', 'transfer-pay' ), $labels['title'] ),
				'default' => 'no',
			),
			'title'          => array(
				'title'       => __( 'Title', 'transfer-pay' ),
				'type'        => 'text',
				'description' => __( 'What shoppers see at checkout.', 'transfer-pay' ),
				'default'     => $labels['title'],
				'desc_tip'    => true,
			),
			'description'    => array(
				'title'       => __( 'Description', 'transfer-pay' ),
				'type'        => 'textarea',
				'description' => __( 'Shown under the title at checkout.', 'transfer-pay' ),
				'default'     => $labels['description'],
				'desc_tip'    => true,
			),
			'bank_name'      => array(
				'title'       => __( 'Bank name', 'transfer-pay' ),
				'type'        => 'text',
				'placeholder' => __( 'e.g. BPI', 'transfer-pay' ),
				'default'     => '',
			),
			'account_name'   => array(
				'title'       => __( 'Account name', 'transfer-pay' ),
				'type'        => 'text',
				'description' => __( 'The name shoppers will see when they send the money.', 'transfer-pay' ),
				'default'     => '',
				'desc_tip'    => true,
			),
			'account_number' => array(
				'title'       => 'bank' === $this->wallet ? __( 'Account number', 'transfer-pay' ) : __( 'Mobile number', 'transfer-pay' ),
				'type'        => 'text',
				'description' => __( 'Required. The method stays hidden at checkout until this is filled in.', 'transfer-pay' ),
				'default'     => '',
			),
			'qr_image'       => array(
				'title'       => __( 'QR code image URL', 'transfer-pay' ),
				'type'        => 'url',
				'description' => __( 'Optional. Upload your QR code in Media, then paste its URL here.', 'transfer-pay' ),
				'placeholder' => 'https://',
				'default'     => '',
			),
			'instructions'   => array(
				'title'       => __( 'Extra instructions', 'transfer-pay' ),
				'type'        => 'textarea',
				'description' => __( 'Optional. Added to the thank-you page and the "How to pay" email.', 'transfer-pay' ),
				'default'     => '',
				'desc_tip'    => true,
			),
			'expire_hours'   => array(
				'title'             => __( 'Cancel unpaid orders after', 'transfer-pay' ),
				'type'              => 'number',
				'description'       => __( 'Hours. Unpaid orders are cancelled and their stock released. Use 0 to keep them open.', 'transfer-pay' ),
				'default'           => '48',
				'custom_attributes' => array(
					'min'  => '0',
					'step' => '1',
				),
			),
		);

		if ( 'bank' !== $this->wallet ) {
			unset( $this->form_fields['bank_name'] );
		}
	}

	/**
	 * Only offer the method once the shop has said where to send the money.
	 *
	 * @return bool
	 */
	public function is_available() {
		return parent::is_available() && '' !== trim( (string) $this->get_option( 'account_number' ) );
	}

	/**
	 * Keep the QR field a clean URL.
	 *
	 * @param string $key   Field key.
	 * @param string $value Posted value.
	 * @return string
	 */
	public function validate_qr_image_field( $key, $value ) {
		return esc_url_raw( trim( (string) $value ) );
	}

	/**
	 * Keep the expiry a whole number of hours.
	 *
	 * @param string $key   Field key.
	 * @param string $value Posted value.
	 * @return string
	 */
	public function validate_expire_hours_field( $key, $value ) {
		return (string) absint( $value );
	}

	/**
	 * Place the order on hold for the transfer.
	 *
	 * @param int $order_id Order ID.
	 * @return array
	 */
	public function process_payment( $order_id ) {
		$order = wc_get_order( $order_id );

		/* translators: %s: payment method name, e.g. GCash. */
		$order->update_status( 'tp-awaiting', sprintf( __( 'Awaiting %s transfer.', 'transfer-pay' ), $this->get_title() ) );
		// The "maybe" variant also flags the order as stock-reduced, which is what lets a later cancel restock it.
		wc_maybe_reduce_stock_levels( $order->get_id() );
		Transfer_Pay::schedule_expiry( $order );

		if ( WC()->cart ) {
			WC()->cart->empty_cart();
		}

		return array(
			'result'   => 'success',
			'redirect' => $this->get_return_url( $order ),
		);
	}
}
