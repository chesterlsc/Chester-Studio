<?php
/**
 * Proof-of-payment storage: shopper upload (a trust boundary) and admin-only viewing.
 *
 * @package Transfer_Pay
 */

defined( 'ABSPATH' ) || exit;

/**
 * Stores payment proofs in a private uploads folder and serves them to shop staff only.
 */
final class Transfer_Pay_Proof {

	/**
	 * Largest accepted proof, in bytes (5 MB).
	 */
	const MAX_BYTES = 5242880;

	/**
	 * Accepted extensions (regex keys, like core's mime list) and their MIME types.
	 */
	const MIMES = array(
		'jpg|jpeg' => 'image/jpeg',
		'png'      => 'image/png',
		'webp'     => 'image/webp',
		'pdf'      => 'application/pdf',
	);

	/**
	 * Register the upload and view endpoints.
	 */
	public static function init() {
		add_action( 'admin_post_tp_upload_proof', array( __CLASS__, 'handle_upload' ) );
		add_action( 'admin_post_nopriv_tp_upload_proof', array( __CLASS__, 'handle_upload' ) );
		add_action( 'admin_post_tp_view_proof', array( __CLASS__, 'serve_proof' ) );
	}

	/**
	 * Whether this order can take a (new) proof right now.
	 *
	 * @param WC_Order $order Order.
	 * @return bool
	 */
	public static function accepts_proof( $order ) {
		return Transfer_Pay::is_transfer_order( $order ) && $order->has_status( array( 'tp-awaiting', 'tp-review' ) );
	}

	/**
	 * Look up an order from a shopper's form post. The order key is the shopper's credential.
	 *
	 * @param int    $order_id  Order ID.
	 * @param string $order_key Posted order key.
	 * @return WC_Order|WP_Error
	 */
	public static function get_customer_order( $order_id, $order_key ) {
		$order = $order_id ? wc_get_order( $order_id ) : false;

		if ( ! $order instanceof WC_Order || ! is_string( $order_key ) || '' === $order_key || ! hash_equals( $order->get_order_key(), $order_key ) ) {
			return new WP_Error( 'invalid_order', __( 'We could not find that order.', 'transfer-pay' ) );
		}

		return $order;
	}

	/**
	 * Request handler for admin-post.php?action=tp_upload_proof. Redirects back with ?tp_proof={result}.
	 */
	public static function handle_upload() {
		$order_id = isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0;
		$nonce    = isset( $_POST['tp_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['tp_nonce'] ) ) : '';

		if ( ! wp_verify_nonce( $nonce, 'tp_upload_proof_' . $order_id ) ) {
			wp_die( esc_html__( 'This page has expired. Please go back, refresh and try again.', 'transfer-pay' ), '', array( 'response' => 403, 'back_link' => true ) );
		}

		$order_key = isset( $_POST['order_key'] ) ? sanitize_text_field( wp_unslash( $_POST['order_key'] ) ) : '';
		$order     = self::get_customer_order( $order_id, $order_key );
		if ( is_wp_error( $order ) ) {
			wp_die( esc_html( $order->get_error_message() ), '', array( 'response' => 403, 'back_link' => true ) );
		}

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- Validated field by field below; the file is judged by its content, never its claimed type.
		$file      = isset( $_FILES['tp_proof'] ) && is_array( $_FILES['tp_proof'] ) ? $_FILES['tp_proof'] : array();
		$reference = isset( $_POST['tp_reference'] ) ? sanitize_text_field( wp_unslash( $_POST['tp_reference'] ) ) : '';
		$error     = isset( $file['error'] ) && is_int( $file['error'] ) ? $file['error'] : UPLOAD_ERR_NO_FILE;

		if ( UPLOAD_ERR_NO_FILE === $error ) {
			$result = new WP_Error( 'no_file' );
		} elseif ( UPLOAD_ERR_INI_SIZE === $error || UPLOAD_ERR_FORM_SIZE === $error ) {
			$result = new WP_Error( 'too_large' );
		} elseif ( UPLOAD_ERR_OK !== $error || ! is_string( $file['tmp_name'] ?? null ) || ! is_string( $file['name'] ?? null ) || ! is_uploaded_file( $file['tmp_name'] ) ) {
			$result = new WP_Error( 'upload_failed' );
		} else {
			$result = self::save_proof( $order, $file['tmp_name'], sanitize_file_name( $file['name'] ), $reference );
		}

		$back = wp_get_referer();
		if ( ! $back ) {
			$back = $order->get_checkout_order_received_url();
		}
		$flag = is_wp_error( $result ) ? $result->get_error_code() : 'uploaded';

		wp_safe_redirect( add_query_arg( 'tp_proof', $flag, remove_query_arg( 'tp_proof', $back ) ) . '#tp-panel' );
		exit;
	}

	/**
	 * Validate and store a proof, then move the order to "Proof received".
	 * Takes plain values (not $_FILES) so it can be exercised directly.
	 *
	 * @param WC_Order $order         Order the proof belongs to.
	 * @param string   $tmp_path      Path to the uploaded file.
	 * @param string   $original_name The shopper's file name; only its extension is used.
	 * @param string   $reference     Optional transaction reference number.
	 * @return true|WP_Error
	 */
	public static function save_proof( $order, $tmp_path, $original_name, $reference = '' ) {
		if ( ! self::accepts_proof( $order ) ) {
			return new WP_Error( 'not_allowed', __( 'This order is not waiting for a payment proof.', 'transfer-pay' ) );
		}

		$size = is_file( $tmp_path ) ? (int) filesize( $tmp_path ) : 0;
		if ( $size < 1 ) {
			return new WP_Error( 'upload_failed', __( 'The upload did not go through.', 'transfer-pay' ) );
		}
		if ( $size > self::MAX_BYTES ) {
			return new WP_Error( 'too_large', __( 'The file is larger than 5 MB.', 'transfer-pay' ) );
		}

		// Checks the real content, not just the name; images are re-checked against their bytes.
		$check = wp_check_filetype_and_ext( $tmp_path, $original_name, self::MIMES );
		if ( empty( $check['ext'] ) || empty( $check['type'] ) ) {
			return new WP_Error( 'invalid_type', __( 'Only JPG, PNG, WebP or PDF files are accepted.', 'transfer-pay' ) );
		}
		if ( 'application/pdf' === $check['type'] ) {
			$valid = '%PDF-' === file_get_contents( $tmp_path, false, null, 0, 5 ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Local file, 5-byte magic check.
		} else {
			$valid = false !== @getimagesize( $tmp_path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- Garbage input is expected here.
		}
		if ( ! $valid ) {
			return new WP_Error( 'invalid_type', __( 'Only JPG, PNG, WebP or PDF files are accepted.', 'transfer-pay' ) );
		}

		$dir = self::get_dir();
		if ( ! $dir ) {
			return new WP_Error( 'upload_failed', __( 'The proof could not be saved.', 'transfer-pay' ) );
		}

		$name = $order->get_id() . '-' . wp_generate_password( 24, false ) . '.' . strtolower( $check['ext'] );
		if ( ! copy( $tmp_path, $dir . $name ) ) {
			return new WP_Error( 'upload_failed', __( 'The proof could not be saved.', 'transfer-pay' ) );
		}

		$previous  = self::get_proof_path( $order );
		$reference = mb_substr( sanitize_text_field( $reference ), 0, 64 );

		$order->update_meta_data( '_tp_proof_file', $name );
		$order->update_meta_data( '_tp_proof_mime', $check['type'] );
		$order->update_meta_data( '_tp_proof_uploaded_at', time() );
		$order->update_meta_data( '_tp_reference', $reference );
		$order->delete_meta_data( '_tp_reject_reason' );

		$note = '' === $reference
			? __( 'Payment proof uploaded. Check it against your account, then verify or reject it.', 'transfer-pay' )
			/* translators: %s: transaction reference number entered by the shopper. */
			: sprintf( __( 'Payment proof uploaded (reference %s). Check it against your account, then verify or reject it.', 'transfer-pay' ), $reference );

		if ( $order->has_status( 'tp-awaiting' ) ) {
			$order->set_status( 'tp-review', $note );
		} else {
			$order->add_order_note( __( 'Payment proof replaced by the shopper.', 'transfer-pay' ) . ' ' . $note );
		}
		$order->save();

		if ( $previous ) {
			wp_delete_file( $previous );
		}

		/**
		 * Fires after a shopper uploads a payment proof. Sends the admin "Payment proof received" email.
		 *
		 * @param int      $order_id Order ID.
		 * @param WC_Order $order    Order.
		 */
		do_action( 'transfer_pay_proof_uploaded', $order->get_id(), $order );

		return true;
	}

	/**
	 * Private folder for proofs, created on first use with web access denied.
	 *
	 * @return string|false Absolute path with trailing slash, or false.
	 */
	public static function get_dir() {
		$uploads = wp_upload_dir( null, false );
		if ( ! empty( $uploads['error'] ) ) {
			return false;
		}

		$dir = trailingslashit( $uploads['basedir'] ) . 'transfer-pay/';
		if ( ! is_dir( $dir ) && ! wp_mkdir_p( $dir ) ) {
			return false;
		}

		// phpcs:disable WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- Tiny guard files in our own folder.
		if ( ! file_exists( $dir . '.htaccess' ) ) {
			file_put_contents( $dir . '.htaccess', "<IfModule mod_authz_core.c>\n\tRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n\tDeny from all\n</IfModule>\n" );
		}
		if ( ! file_exists( $dir . 'index.php' ) ) {
			file_put_contents( $dir . 'index.php', '' );
		}
		// phpcs:enable

		return $dir;
	}

	/**
	 * Absolute path of an order's proof, only if it really sits inside the private folder.
	 *
	 * @param WC_Order $order Order.
	 * @return string|false
	 */
	public static function get_proof_path( $order ) {
		$file = (string) $order->get_meta( '_tp_proof_file' );
		$dir  = self::get_dir();
		if ( '' === $file || ! $dir ) {
			return false;
		}

		$real_dir = realpath( $dir );
		$real     = realpath( $dir . $file );
		if ( ! $real_dir || ! $real || 0 !== strpos( $real, trailingslashit( $real_dir ) ) || ! is_file( $real ) ) {
			return false;
		}

		return $real;
	}

	/**
	 * Admin-only viewer URL for an order's proof.
	 *
	 * @param WC_Order $order Order.
	 * @return string
	 */
	public static function get_view_url( $order ) {
		$url = add_query_arg(
			array(
				'action'   => 'tp_view_proof',
				'order_id' => $order->get_id(),
			),
			admin_url( 'admin-post.php' )
		);

		return wp_nonce_url( $url, 'tp_view_proof_' . $order->get_id() );
	}

	/**
	 * Request handler for admin-post.php?action=tp_view_proof. Streams the file to shop staff.
	 */
	public static function serve_proof() {
		$order_id = isset( $_GET['order_id'] ) ? absint( $_GET['order_id'] ) : 0;
		check_admin_referer( 'tp_view_proof_' . $order_id );

		if ( ! current_user_can( 'edit_shop_orders' ) ) {
			wp_die( esc_html__( 'You are not allowed to view payment proofs.', 'transfer-pay' ), '', array( 'response' => 403 ) );
		}

		$order = wc_get_order( $order_id );
		$path  = $order instanceof WC_Order ? self::get_proof_path( $order ) : false;
		$type  = $path ? wp_check_filetype( $path, self::MIMES ) : array( 'type' => false );
		if ( ! $path || ! $type['type'] ) {
			wp_die( esc_html__( 'Payment proof not found.', 'transfer-pay' ), '', array( 'response' => 404 ) );
		}

		while ( ob_get_level() ) {
			ob_end_clean();
		}

		nocache_headers();
		header( 'Content-Type: ' . $type['type'] );
		header( 'Content-Length: ' . filesize( $path ) );
		header( 'Content-Disposition: inline; filename="' . basename( $path ) . '"' );
		header( 'X-Content-Type-Options: nosniff' );

		readfile( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile -- Streaming a private file.
		exit;
	}
}
