<?php
/**
 * Bootstrap: order statuses, gateway and email registration, unpaid-order expiry.
 *
 * @package Transfer_Pay
 */

defined( 'ABSPATH' ) || exit;

/**
 * Wires Transfer Pay into WooCommerce.
 */
final class Transfer_Pay {

	/**
	 * Wallet keys. Each becomes a gateway with the ID `tp_{key}`.
	 */
	const WALLETS = array( 'gcash', 'maya', 'bank' );

	/**
	 * Action Scheduler hook and group used to cancel unpaid orders.
	 */
	const EXPIRE_HOOK  = 'transfer_pay_expire_order';
	const EXPIRE_GROUP = 'transfer-pay';

	/**
	 * Hook everything up once WooCommerce is loaded.
	 */
	public static function init() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}

		require_once TRANSFER_PAY_PATH . 'includes/class-transfer-pay-gateway.php';
		require_once TRANSFER_PAY_PATH . 'includes/class-transfer-pay-proof.php';
		require_once TRANSFER_PAY_PATH . 'includes/class-transfer-pay-frontend.php';
		require_once TRANSFER_PAY_PATH . 'includes/class-transfer-pay-admin.php';

		add_action( 'init', array( __CLASS__, 'register_statuses' ) );
		add_filter( 'wc_order_statuses', array( __CLASS__, 'add_order_statuses' ) );
		add_filter( 'woocommerce_valid_order_statuses_for_cancel', array( __CLASS__, 'add_cancellable_status' ) );
		add_filter( 'woocommerce_valid_order_statuses_for_payment_complete', array( __CLASS__, 'add_payable_statuses' ) );

		add_filter( 'woocommerce_payment_gateways', array( __CLASS__, 'add_gateways' ) );
		add_action( 'woocommerce_blocks_payment_method_type_registration', array( __CLASS__, 'register_block_methods' ) );

		add_filter( 'woocommerce_email_classes', array( __CLASS__, 'add_emails' ) );
		add_filter( 'woocommerce_email_actions', array( __CLASS__, 'add_email_actions' ) );
		add_action( 'woocommerce_email', array( __CLASS__, 'hook_core_emails' ) );

		add_action( self::EXPIRE_HOOK, array( __CLASS__, 'expire_order' ) );

		Transfer_Pay_Proof::init();
		Transfer_Pay_Frontend::init();
		Transfer_Pay_Admin::init();
	}

	/**
	 * Declare HPOS and Cart/Checkout block compatibility.
	 */
	public static function declare_compatibility() {
		if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', TRANSFER_PAY_FILE, true );
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', TRANSFER_PAY_FILE, true );
		}
	}

	/**
	 * Per-wallet labels and defaults.
	 *
	 * @param string $wallet Wallet key.
	 * @return array{title: string, description: string, app: string, icon: string}
	 */
	public static function wallet( $wallet ) {
		$wallets = array(
			'gcash' => array(
				'title'       => __( 'GCash', 'transfer-pay' ),
				'description' => __( 'Send the total from your GCash app. After you place the order we show the account details, and you upload your receipt on the same page.', 'transfer-pay' ),
				'app'         => __( 'your GCash app', 'transfer-pay' ),
				'icon'        => 'phone-wallet.svg',
			),
			'maya'  => array(
				'title'       => __( 'Maya', 'transfer-pay' ),
				'description' => __( 'Send the total from your Maya app. After you place the order we show the account details, and you upload your receipt on the same page.', 'transfer-pay' ),
				'app'         => __( 'your Maya app', 'transfer-pay' ),
				'icon'        => 'wallet.svg',
			),
			'bank'  => array(
				'title'       => __( 'Bank transfer', 'transfer-pay' ),
				'description' => __( 'Transfer the total from your bank app via InstaPay or PESONet. After you place the order we show the account details, and you upload your receipt on the same page.', 'transfer-pay' ),
				'app'         => __( 'your banking app', 'transfer-pay' ),
				'icon'        => 'bank.svg',
			),
		);

		return $wallets[ $wallet ];
	}

	/**
	 * Gateway IDs owned by this plugin.
	 *
	 * @return string[]
	 */
	public static function gateway_ids() {
		return array( 'tp_gcash', 'tp_maya', 'tp_bank' );
	}

	/**
	 * Whether an order was placed with one of our gateways.
	 *
	 * @param mixed $order Anything; only WC_Order instances can match.
	 * @return bool
	 */
	public static function is_transfer_order( $order ) {
		return $order instanceof WC_Order && in_array( $order->get_payment_method(), self::gateway_ids(), true );
	}

	/**
	 * The gateway instance an order was placed with.
	 *
	 * @param WC_Order $order Order.
	 * @return Transfer_Pay_Gateway|null
	 */
	public static function get_gateway( WC_Order $order ) {
		$gateways = WC()->payment_gateways()->payment_gateways();
		$id       = $order->get_payment_method();

		return isset( $gateways[ $id ] ) && $gateways[ $id ] instanceof Transfer_Pay_Gateway ? $gateways[ $id ] : null;
	}

	/**
	 * Rows the shopper needs to make the transfer, shared by the thank-you panel and emails.
	 *
	 * @param WC_Order                  $order   Order.
	 * @param Transfer_Pay_Gateway|null $gateway Gateway; defaults to the order's own.
	 * @return array<string, array{label: string, value: string, copy: string}>
	 */
	public static function get_payment_details( WC_Order $order, $gateway = null ) {
		$gateway = $gateway ? $gateway : self::get_gateway( $order );
		$amount  = wc_price( $order->get_total(), array( 'currency' => $order->get_currency() ) );
		$rows    = array(
			'amount' => array(
				'label' => __( 'Amount to send', 'transfer-pay' ),
				'value' => html_entity_decode( wp_strip_all_tags( $amount ), ENT_QUOTES, 'UTF-8' ),
				'copy'  => wc_format_decimal( $order->get_total(), wc_get_price_decimals() ),
			),
		);

		if ( $gateway ) {
			$fields = array(
				'bank_name'      => __( 'Bank', 'transfer-pay' ),
				'account_name'   => __( 'Account name', 'transfer-pay' ),
				'account_number' => 'bank' === $gateway->wallet ? __( 'Account number', 'transfer-pay' ) : __( 'Mobile number', 'transfer-pay' ),
			);

			foreach ( $fields as $key => $label ) {
				$value = trim( (string) $gateway->get_option( $key ) );
				if ( '' === $value ) {
					continue;
				}
				$copy = $value;
				if ( 'bank_name' === $key ) {
					$copy = '';
				} elseif ( 'account_number' === $key ) {
					$copy = preg_replace( '/\s+/', '', $value );
				}
				$rows[ $key ] = array(
					'label' => $label,
					'value' => $value,
					'copy'  => $copy,
				);
			}
		}

		$rows['reference'] = array(
			'label' => __( 'Reference / message', 'transfer-pay' ),
			'value' => $order->get_order_number(),
			'copy'  => $order->get_order_number(),
		);

		return $rows;
	}

	/**
	 * Register the two unpaid order statuses.
	 */
	public static function register_statuses() {
		register_post_status(
			'wc-tp-awaiting',
			array(
				'label'                     => _x( 'Awaiting transfer', 'Order status', 'transfer-pay' ),
				'public'                    => false,
				'exclude_from_search'       => false,
				'show_in_admin_all_list'    => true,
				'show_in_admin_status_list' => true,
				/* translators: %s: number of orders */
				'label_count'               => _n_noop( 'Awaiting transfer <span class="count">(%s)</span>', 'Awaiting transfer <span class="count">(%s)</span>', 'transfer-pay' ),
			)
		);

		register_post_status(
			'wc-tp-review',
			array(
				'label'                     => _x( 'Proof received', 'Order status', 'transfer-pay' ),
				'public'                    => false,
				'exclude_from_search'       => false,
				'show_in_admin_all_list'    => true,
				'show_in_admin_status_list' => true,
				/* translators: %s: number of orders */
				'label_count'               => _n_noop( 'Proof received <span class="count">(%s)</span>', 'Proof received <span class="count">(%s)</span>', 'transfer-pay' ),
			)
		);
	}

	/**
	 * Add our statuses to WooCommerce's list, right after "Pending payment".
	 *
	 * @param array $statuses Status slug => label.
	 * @return array
	 */
	public static function add_order_statuses( $statuses ) {
		$ours = array(
			'wc-tp-awaiting' => _x( 'Awaiting transfer', 'Order status', 'transfer-pay' ),
			'wc-tp-review'   => _x( 'Proof received', 'Order status', 'transfer-pay' ),
		);
		$out  = array();

		foreach ( $statuses as $key => $label ) {
			$out[ $key ] = $label;
			if ( 'wc-pending' === $key ) {
				$out += $ours;
			}
		}

		return $out + $ours;
	}

	/**
	 * Let shoppers cancel an order they have not paid for yet.
	 *
	 * @param string[] $statuses Statuses.
	 * @return string[]
	 */
	public static function add_cancellable_status( $statuses ) {
		$statuses[] = 'tp-awaiting';
		return $statuses;
	}

	/**
	 * Let payment_complete() move our unpaid statuses to processing/completed.
	 *
	 * @param string[] $statuses Statuses.
	 * @return string[]
	 */
	public static function add_payable_statuses( $statuses ) {
		$statuses[] = 'tp-awaiting';
		$statuses[] = 'tp-review';
		return $statuses;
	}

	/**
	 * Register one gateway instance per wallet.
	 *
	 * @param array $gateways Gateway class names or instances.
	 * @return array
	 */
	public static function add_gateways( $gateways ) {
		foreach ( self::WALLETS as $wallet ) {
			$gateways[] = new Transfer_Pay_Gateway( $wallet );
		}
		return $gateways;
	}

	/**
	 * Register the gateways with the Cart and Checkout blocks.
	 *
	 * @param \Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $registry Registry.
	 */
	public static function register_block_methods( $registry ) {
		require_once TRANSFER_PAY_PATH . 'includes/class-transfer-pay-blocks.php';

		$gateways = WC()->payment_gateways()->payment_gateways();
		foreach ( self::gateway_ids() as $id ) {
			if ( isset( $gateways[ $id ] ) ) {
				$registry->register( new Transfer_Pay_Blocks( $gateways[ $id ] ) );
			}
		}
	}

	/**
	 * Register our emails so they show in WooCommerce > Settings > Emails.
	 *
	 * @param WC_Email[] $emails Emails.
	 * @return WC_Email[]
	 */
	public static function add_emails( $emails ) {
		require_once TRANSFER_PAY_PATH . 'includes/emails/class-transfer-pay-email.php';
		require_once TRANSFER_PAY_PATH . 'includes/emails/class-transfer-pay-email-instructions.php';
		require_once TRANSFER_PAY_PATH . 'includes/emails/class-transfer-pay-email-proof-received.php';
		require_once TRANSFER_PAY_PATH . 'includes/emails/class-transfer-pay-email-rejected.php';

		$emails['Transfer_Pay_Email_Instructions']   = new Transfer_Pay_Email_Instructions();
		$emails['Transfer_Pay_Email_Proof_Received'] = new Transfer_Pay_Email_Proof_Received();
		$emails['Transfer_Pay_Email_Rejected']       = new Transfer_Pay_Email_Rejected();

		return $emails;
	}

	/**
	 * Actions that load the mailer and fire `{action}_notification`.
	 *
	 * @param string[] $actions Actions.
	 * @return string[]
	 */
	public static function add_email_actions( $actions ) {
		return array_merge(
			$actions,
			array(
				'woocommerce_order_status_tp-awaiting',
				'woocommerce_order_status_pending_to_tp-awaiting',
				'woocommerce_order_status_tp-awaiting_to_processing',
				'woocommerce_order_status_tp-review_to_processing',
				'transfer_pay_proof_uploaded',
				'transfer_pay_proof_rejected',
			)
		);
	}

	/**
	 * Core emails do not know our statuses: tell the shop about new transfer orders,
	 * and send the shopper the usual "processing" email once the transfer is verified.
	 *
	 * @param WC_Emails $mailer Mailer.
	 */
	public static function hook_core_emails( $mailer ) {
		if ( isset( $mailer->emails['WC_Email_New_Order'] ) ) {
			add_action( 'woocommerce_order_status_pending_to_tp-awaiting_notification', array( $mailer->emails['WC_Email_New_Order'], 'trigger' ), 10, 2 );
		}
		if ( isset( $mailer->emails['WC_Email_Customer_Processing_Order'] ) ) {
			add_action( 'woocommerce_order_status_tp-awaiting_to_processing_notification', array( $mailer->emails['WC_Email_Customer_Processing_Order'], 'trigger' ), 10, 2 );
			add_action( 'woocommerce_order_status_tp-review_to_processing_notification', array( $mailer->emails['WC_Email_Customer_Processing_Order'], 'trigger' ), 10, 2 );
		}
	}

	/**
	 * (Re)schedule the auto-cancel for an unpaid order, using its gateway's time limit.
	 *
	 * @param WC_Order $order Order.
	 */
	public static function schedule_expiry( WC_Order $order ) {
		if ( ! function_exists( 'as_schedule_single_action' ) ) {
			return;
		}

		$args = array( 'order_id' => $order->get_id() );
		as_unschedule_all_actions( self::EXPIRE_HOOK, $args, self::EXPIRE_GROUP );

		$gateway = self::get_gateway( $order );
		$hours   = $gateway ? absint( $gateway->get_option( 'expire_hours' ) ) : 0;
		if ( $hours > 0 ) {
			as_schedule_single_action( time() + $hours * HOUR_IN_SECONDS, self::EXPIRE_HOOK, $args, self::EXPIRE_GROUP );
		}
	}

	/**
	 * Action Scheduler callback: cancel the order if the shopper still has not paid.
	 * Cancelling through WooCommerce restocks the items.
	 *
	 * @param int $order_id Order ID.
	 */
	public static function expire_order( $order_id ) {
		$order = wc_get_order( $order_id );

		if ( $order instanceof WC_Order && $order->has_status( 'tp-awaiting' ) ) {
			$order->update_status( 'cancelled', __( 'No transfer received within the time limit. Order cancelled and stock released.', 'transfer-pay' ) );
		}
	}
}
