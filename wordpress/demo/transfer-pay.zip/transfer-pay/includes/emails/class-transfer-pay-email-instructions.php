<?php
/**
 * Customer email: how to pay.
 *
 * @package Transfer_Pay
 */

defined( 'ABSPATH' ) || exit;

/**
 * Sent exactly once per order when it first reaches "Awaiting transfer".
 */
class Transfer_Pay_Email_Instructions extends Transfer_Pay_Email {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->id             = 'tp_customer_instructions';
		$this->customer_email = true;
		$this->title          = __( 'Transfer: how to pay', 'transfer-pay' );
		$this->description    = __( 'Sent once to the shopper after a GCash, Maya or bank-transfer order: the amount, account details, QR code and a link to upload their proof.', 'transfer-pay' );
		$this->template_html  = 'emails/tp-customer-instructions.php';
		$this->template_plain = 'emails/plain/tp-customer-instructions.php';

		add_action( 'woocommerce_order_status_tp-awaiting_notification', array( $this, 'trigger' ), 10, 2 );

		parent::__construct();
	}

	/**
	 * Default subject.
	 *
	 * @return string
	 */
	public function get_default_subject() {
		return __( 'How to pay for your {site_title} order #{order_number}', 'transfer-pay' );
	}

	/**
	 * Default heading.
	 *
	 * @return string
	 */
	public function get_default_heading() {
		return __( 'How to pay for your order', 'transfer-pay' );
	}

	/**
	 * Send, at most once per order.
	 *
	 * The order is claimed (meta saved) before sending, so a status that flips back to
	 * "Awaiting transfer" or a hook that fires twice cannot send it again. If sending
	 * fails the claim is released so a later trigger can retry.
	 *
	 * @param int            $order_id Order ID.
	 * @param WC_Order|false $order    Order.
	 */
	public function trigger( $order_id, $order = false ) {
		$this->setup_locale();

		if ( $this->load_order( $order_id, $order ) && $this->is_enabled() ) {
			$order           = $this->object;
			$this->recipient = $order->get_billing_email();

			if ( $this->get_recipient() && ! $order->get_meta( '_tp_instructions_sent' ) ) {
				$order->update_meta_data( '_tp_instructions_sent', time() );
				$order->save_meta_data();

				if ( ! $this->send( $this->get_recipient(), $this->get_subject(), $this->get_content(), $this->get_headers(), $this->get_attachments() ) ) {
					$order->delete_meta_data( '_tp_instructions_sent' );
					$order->save_meta_data();
				}
			}
		}

		$this->restore_locale();
	}
}
