<?php
/**
 * Admin email: payment proof received.
 *
 * @package Transfer_Pay
 */

defined( 'ABSPATH' ) || exit;

/**
 * Tells the shop a proof is waiting, with the proof attached.
 */
class Transfer_Pay_Email_Proof_Received extends Transfer_Pay_Email {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->id             = 'tp_admin_proof_received';
		$this->title          = __( 'Transfer: payment proof received', 'transfer-pay' );
		$this->description    = __( 'Sent to the shop when a shopper uploads a payment proof. The proof is attached.', 'transfer-pay' );
		$this->template_html  = 'emails/tp-admin-proof-received.php';
		$this->template_plain = 'emails/plain/tp-admin-proof-received.php';

		add_action( 'transfer_pay_proof_uploaded_notification', array( $this, 'trigger' ), 10, 2 );

		parent::__construct();

		$this->recipient = $this->get_option( 'recipient', get_option( 'admin_email' ) );
	}

	/**
	 * Default subject.
	 *
	 * @return string
	 */
	public function get_default_subject() {
		return __( '[{site_title}]: Payment proof for order #{order_number}', 'transfer-pay' );
	}

	/**
	 * Default heading.
	 *
	 * @return string
	 */
	public function get_default_heading() {
		return __( 'Payment proof received', 'transfer-pay' );
	}

	/**
	 * Send to the shop.
	 *
	 * @param int            $order_id Order ID.
	 * @param WC_Order|false $order    Order.
	 */
	public function trigger( $order_id, $order = false ) {
		$this->setup_locale();

		if ( $this->load_order( $order_id, $order ) && $this->is_enabled() && $this->get_recipient() ) {
			$this->send( $this->get_recipient(), $this->get_subject(), $this->get_content(), $this->get_headers(), $this->get_attachments() );
		}

		$this->restore_locale();
	}

	/**
	 * Attach the proof file.
	 *
	 * @return string[]
	 */
	public function get_attachments() {
		$attachments = parent::get_attachments();
		$path        = $this->object instanceof WC_Order ? Transfer_Pay_Proof::get_proof_path( $this->object ) : false;

		if ( $path ) {
			$attachments[] = $path;
		}

		return $attachments;
	}

	/**
	 * Add a recipient setting, like the core "New order" email.
	 */
	public function init_form_fields() {
		parent::init_form_fields();

		$this->form_fields = array_merge(
			array(
				'enabled'   => $this->form_fields['enabled'],
				'recipient' => array(
					'title'       => __( 'Recipient(s)', 'transfer-pay' ),
					'type'        => 'text',
					/* translators: %s: site admin email address. */
					'description' => sprintf( __( 'Comma-separated. Defaults to %s.', 'transfer-pay' ), '<code>' . esc_html( get_option( 'admin_email' ) ) . '</code>' ),
					'placeholder' => '',
					'default'     => '',
					'desc_tip'    => true,
				),
			),
			$this->form_fields
		);
	}
}
