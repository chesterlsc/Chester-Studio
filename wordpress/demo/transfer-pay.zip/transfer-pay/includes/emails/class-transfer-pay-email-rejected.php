<?php
/**
 * Customer email: transfer not confirmed.
 *
 * @package Transfer_Pay
 */

defined( 'ABSPATH' ) || exit;

/**
 * Tells the shopper why their proof was rejected and where to upload a new one.
 */
class Transfer_Pay_Email_Rejected extends Transfer_Pay_Email {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->id             = 'tp_customer_rejected';
		$this->customer_email = true;
		$this->title          = __( 'Transfer: not confirmed', 'transfer-pay' );
		$this->description    = __( 'Sent to the shopper when you reject their payment proof, with your reason and a link to upload a new one.', 'transfer-pay' );
		$this->template_html  = 'emails/tp-customer-rejected.php';
		$this->template_plain = 'emails/plain/tp-customer-rejected.php';

		add_action( 'transfer_pay_proof_rejected_notification', array( $this, 'trigger' ), 10, 2 );

		parent::__construct();
	}

	/**
	 * Default subject.
	 *
	 * @return string
	 */
	public function get_default_subject() {
		return __( 'We could not confirm your payment for order #{order_number}', 'transfer-pay' );
	}

	/**
	 * Default heading.
	 *
	 * @return string
	 */
	public function get_default_heading() {
		return __( 'We could not confirm your transfer', 'transfer-pay' );
	}

	/**
	 * Send to the shopper.
	 *
	 * @param int            $order_id Order ID.
	 * @param WC_Order|false $order    Order.
	 */
	public function trigger( $order_id, $order = false ) {
		$this->setup_locale();

		if ( $this->load_order( $order_id, $order ) && $this->is_enabled() ) {
			$this->recipient = $this->object->get_billing_email();

			if ( $this->get_recipient() ) {
				$this->send( $this->get_recipient(), $this->get_subject(), $this->get_content(), $this->get_headers(), $this->get_attachments() );
			}
		}

		$this->restore_locale();
	}
}
