<?php
/**
 * Shared base for Transfer Pay emails.
 *
 * @package Transfer_Pay
 */

defined( 'ABSPATH' ) || exit;

/**
 * Loads templates from this plugin (theme-overridable at yourtheme/woocommerce/emails/).
 */
abstract class Transfer_Pay_Email extends WC_Email {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->template_base = TRANSFER_PAY_PATH . 'templates/';
		$this->placeholders  = array(
			'{order_number}' => '',
			'{order_date}'   => '',
		);

		parent::__construct();
	}

	/**
	 * Set the email's order if it was paid with one of our gateways.
	 *
	 * @param int            $order_id Order ID.
	 * @param WC_Order|false $order    Order, when the hook passes one.
	 * @return bool Whether the order is ours.
	 */
	protected function load_order( $order_id, $order ) {
		if ( $order_id && ! $order instanceof WC_Order ) {
			$order = wc_get_order( $order_id );
		}
		if ( ! Transfer_Pay::is_transfer_order( $order ) ) {
			return false;
		}

		$this->object                         = $order;
		$this->placeholders['{order_number}'] = $order->get_order_number();
		$this->placeholders['{order_date}']   = wc_format_datetime( $order->get_date_created() );

		return true;
	}

	/**
	 * HTML body.
	 *
	 * @return string
	 */
	public function get_content_html() {
		return wc_get_template_html( $this->template_html, $this->get_template_args( false ), '', $this->template_base );
	}

	/**
	 * Plain-text body.
	 *
	 * @return string
	 */
	public function get_content_plain() {
		return wc_get_template_html( $this->template_plain, $this->get_template_args( true ), '', $this->template_base );
	}

	/**
	 * Variables available to the templates.
	 *
	 * @param bool $plain_text Whether this is the plain-text version.
	 * @return array
	 */
	protected function get_template_args( $plain_text ) {
		$order   = $this->object;
		$gateway = $order instanceof WC_Order ? Transfer_Pay::get_gateway( $order ) : null;

		if ( ! $gateway ) {
			// Email previews in WooCommerce > Settings > Emails use a dummy order paid some other way.
			$gateways = WC()->payment_gateways()->payment_gateways();
			$gateway  = isset( $gateways['tp_gcash'] ) ? $gateways['tp_gcash'] : null;
		}

		return array(
			'order'              => $order,
			'gateway'            => $gateway,
			'details'            => $order instanceof WC_Order ? Transfer_Pay::get_payment_details( $order, $gateway ) : array(),
			'reason'             => $order instanceof WC_Order ? (string) $order->get_meta( '_tp_reject_reason' ) : '',
			'email_heading'      => $this->get_heading(),
			'additional_content' => $this->get_additional_content(),
			'sent_to_admin'      => ! $this->is_customer_email(),
			'plain_text'         => $plain_text,
			'email'              => $this,
		);
	}
}
