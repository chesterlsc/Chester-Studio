=== Transfer Pay for WooCommerce ===
Contributors: chesterstudio
Tags: woocommerce, gcash, maya, bank transfer, philippines
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

GCash, Maya and bank-transfer checkout for Philippine stores, with proof-of-payment upload and one-click verification.

== Description ==

Most small Philippine shops already take payment by GCash, Maya or bank transfer, then chase screenshots over Messenger. Transfer Pay moves that whole loop into WooCommerce.

1. The shopper picks GCash, Maya or Bank transfer at checkout (classic or block checkout).
2. The order is held as **Awaiting transfer** and stock is reserved. The shopper sees the exact amount, your account name and number, your QR code and one-tap copy buttons, and gets the same details by email.
3. The shopper uploads a screenshot or PDF of the receipt, with an optional reference number. The order moves to **Proof received** and you get an email with the proof attached.
4. You open the order, look at the proof and click **Verify payment** (the order moves to Processing) or **Reject** with a reason (the shopper is emailed and can upload again).
5. Orders that are never paid are cancelled automatically after a time limit you choose, and their stock is released.

= Features =

* Three separate methods (GCash, Maya, Bank transfer), each with its own account details, QR code, instructions and time limit.
* Works with the Cart and Checkout blocks and with classic checkout. Compatible with High-Performance Order Storage.
* "How to pay" panel on the thank-you page and in My Account, with copy buttons for the amount, account number and order reference.
* Strict upload checks: JPG, PNG, WebP or PDF only, 5 MB maximum, file contents verified (not just the name).
* Proofs are stored outside public access and only shown to shop staff.
* Three emails you can edit in WooCommerce > Settings > Emails: "How to pay" (sent once per order), "Payment proof received" (to the shop, proof attached) and "Transfer not confirmed".
* The panel picks up your block theme's colours and fonts. Templates can be overridden in your theme.

GCash and Maya are trademarks of their owners. This plugin is not affiliated with or endorsed by them; it simply shows your own account details to your shoppers.

== Installation ==

1. Install and activate WooCommerce, then this plugin.
2. Go to WooCommerce > Settings > Payments and open GCash, Maya or Bank transfer.
3. Enable it and enter the account name and number (the method stays hidden until a number is set). Optionally add a QR code image URL and extra instructions.
4. Place a test order to see the thank-you panel and emails.

== Frequently Asked Questions ==

= Does this connect to GCash or Maya automatically? =

No. Shoppers send money with their own app, exactly as they do today. The plugin gives them the details, collects the proof and lets you confirm it in one click.

= Where are the payment proofs stored? =

In `wp-content/uploads/transfer-pay/`, with random file names. The folder includes an `.htaccess` file that blocks direct access on Apache and LiteSpeed. On Nginx, add a rule such as `location ^~ /wp-content/uploads/transfer-pay/ { deny all; }`. Staff view proofs through a logged-in, capability-checked link in the order screen.

= What happens to stock while the shopper pays? =

Stock is reduced when the order is placed. If the order is cancelled, by the shopper, by you or by the time limit, WooCommerce restores it.

= Can I change the email text? =

Yes. Each email has its own subject, heading and additional content in WooCommerce > Settings > Emails. For deeper changes, copy a template from `templates/emails/` to `yourtheme/woocommerce/emails/`.

= Can I restyle the thank-you panel? =

Yes. All styles have zero specificity, so any theme rule wins. You can also copy `templates/order/tp-payment-panel.php` to `yourtheme/woocommerce/order/`.

== Privacy ==

Payment proofs are screenshots of bank or e-wallet receipts. They can contain names, account or mobile numbers and transaction references, so treat them as financial records:

* They are only visible to users who can edit shop orders.
* They are attached to the "Payment proof received" email, so they also live in the recipients' mailboxes.
* Uninstalling the plugin deletes its settings but keeps the proofs and order data, because shops usually need them for bookkeeping. Delete the `wp-content/uploads/transfer-pay/` folder yourself when your retention period ends.

Consider mentioning proof uploads in your store's privacy policy.

== Changelog ==

= 1.0.0 =
* First release: GCash, Maya and bank transfer methods, proof upload, verify and reject, three emails, automatic expiry, block checkout and HPOS support.
