<?php
/**
 * Admin "Payment proof received" email (plain text).
 *
 * Override by copying to yourtheme/woocommerce/emails/plain/tp-admin-proof-received.php.
 *
 * @package Transfer_Pay
 *
 * @var WC_Order $order              Order.
 * @var array    $details            Rows of label / value.
 * @var string   $email_heading      Heading.
 * @var string   $additional_content Extra content from the email settings.
 * @var bool     $sent_to_admin      Whether sent to the shop.
 * @var bool     $plain_text         Whether plain text.
 * @var WC_Email $email              Email object.
 */

defined( 'ABSPATH' ) || exit;

$tp_reference = (string) $order->get_meta( '_tp_reference' );

echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n";
echo esc_html( wp_strip_all_tags( $email_heading ) );
echo "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n\n";

/* translators: 1: order number, 2: customer name. */
echo esc_html( sprintf( __( 'Order #%1$s from %2$s has a payment proof waiting for you.', 'transfer-pay' ), $order->get_order_number(), $order->get_formatted_billing_full_name() ) ) . "\n\n";

echo esc_html( __( 'Amount', 'transfer-pay' ) . ': ' . $details['amount']['value'] ) . "\n";
echo esc_html( __( 'Method', 'transfer-pay' ) . ': ' . $order->get_payment_method_title() ) . "\n";
echo esc_html( __( 'Reference', 'transfer-pay' ) . ': ' . ( '' !== $tp_reference ? $tp_reference : __( 'Not given', 'transfer-pay' ) ) ) . "\n\n";

echo esc_html__( 'The proof is attached. Check it against your account, then verify or reject it from the order screen:', 'transfer-pay' ) . "\n";
echo esc_url( $order->get_edit_order_url() ) . "\n\n";

echo "----------------------------------------\n\n";

do_action( 'woocommerce_email_order_details', $order, $sent_to_admin, $plain_text, $email );

if ( $additional_content ) {
	echo "\n\n----------------------------------------\n\n";
	echo esc_html( wp_strip_all_tags( wptexturize( $additional_content ) ) );
	echo "\n";
}

echo "\n\n----------------------------------------\n\n";
echo wp_kses_post( apply_filters( 'woocommerce_email_footer_text', get_option( 'woocommerce_email_footer_text' ) ) );
