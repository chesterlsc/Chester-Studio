<?php
/**
 * Customer "How to pay" email (plain text).
 *
 * Override by copying to yourtheme/woocommerce/emails/plain/tp-customer-instructions.php.
 *
 * @package Transfer_Pay
 *
 * @var WC_Order                  $order              Order.
 * @var Transfer_Pay_Gateway|null $gateway            Gateway.
 * @var array                     $details            Rows of label / value.
 * @var string                    $email_heading      Heading.
 * @var string                    $additional_content Extra content from the email settings.
 * @var bool                      $sent_to_admin      Whether sent to the shop.
 * @var bool                      $plain_text         Whether plain text.
 * @var WC_Email                  $email              Email object.
 */

defined( 'ABSPATH' ) || exit;

$tp_hours = $gateway ? absint( $gateway->get_option( 'expire_hours' ) ) : 0;

echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n";
echo esc_html( wp_strip_all_tags( $email_heading ) );
echo "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n\n";

if ( $order->get_billing_first_name() ) {
	/* translators: %s: customer first name. */
	echo sprintf( esc_html__( 'Hi %s,', 'transfer-pay' ), esc_html( $order->get_billing_first_name() ) ) . "\n\n";
} else {
	echo esc_html__( 'Hi,', 'transfer-pay' ) . "\n\n";
}

/* translators: 1: amount, 2: payment method name, e.g. GCash. */
echo esc_html( sprintf( __( 'Thanks for your order. To complete it, send exactly %1$s via %2$s using the details below.', 'transfer-pay' ), $details['amount']['value'], $order->get_payment_method_title() ) ) . "\n\n";

foreach ( $details as $tp_row ) {
	echo esc_html( $tp_row['label'] . ': ' . $tp_row['value'] ) . "\n";
}
echo "\n";

if ( $gateway && $gateway->get_option( 'qr_image' ) ) {
	/* translators: %s: QR code image URL. */
	echo esc_html( sprintf( __( 'QR code: %s', 'transfer-pay' ), $gateway->get_option( 'qr_image' ) ) ) . "\n\n";
}

if ( $gateway && $gateway->get_option( 'instructions' ) ) {
	echo esc_html( wp_strip_all_tags( wptexturize( $gateway->get_option( 'instructions' ) ) ) ) . "\n\n";
}

/* translators: %s: order number. */
echo esc_html( sprintf( __( 'Please write %s in the message or notes field so we can match your payment. Then take a screenshot of the confirmation and upload it here:', 'transfer-pay' ), $order->get_order_number() ) ) . "\n";
echo esc_url( $order->get_checkout_order_received_url() ) . "\n\n";

if ( $tp_hours ) {
	/* translators: %d: number of hours. */
	echo esc_html( sprintf( _n( 'If we do not receive your payment within %d hour, the order is cancelled automatically.', 'If we do not receive your payment within %d hours, the order is cancelled automatically.', $tp_hours, 'transfer-pay' ), $tp_hours ) ) . "\n\n";
}

echo "\n----------------------------------------\n\n";

do_action( 'woocommerce_email_order_details', $order, $sent_to_admin, $plain_text, $email );

if ( $additional_content ) {
	echo "\n\n----------------------------------------\n\n";
	echo esc_html( wp_strip_all_tags( wptexturize( $additional_content ) ) );
	echo "\n";
}

echo "\n\n----------------------------------------\n\n";
echo wp_kses_post( apply_filters( 'woocommerce_email_footer_text', get_option( 'woocommerce_email_footer_text' ) ) );
