<?php
/**
 * Customer "Transfer not confirmed" email (plain text).
 *
 * Override by copying to yourtheme/woocommerce/emails/plain/tp-customer-rejected.php.
 *
 * @package Transfer_Pay
 *
 * @var WC_Order $order              Order.
 * @var array    $details            Rows of label / value.
 * @var string   $reason             Why the proof was rejected.
 * @var string   $email_heading      Heading.
 * @var string   $additional_content Extra content from the email settings.
 * @var bool     $sent_to_admin      Whether sent to the shop.
 * @var bool     $plain_text         Whether plain text.
 * @var WC_Email $email              Email object.
 */

defined( 'ABSPATH' ) || exit;

echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n";
echo esc_html( wp_strip_all_tags( $email_heading ) );
echo "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n\n";

if ( $order->get_billing_first_name() ) {
	/* translators: %s: customer first name. */
	echo sprintf( esc_html__( 'Hi %s,', 'transfer-pay' ), esc_html( $order->get_billing_first_name() ) ) . "\n\n";
} else {
	echo esc_html__( 'Hi,', 'transfer-pay' ) . "\n\n";
}

/* translators: %s: order number. */
echo esc_html( sprintf( __( 'We checked the payment proof for order #%s but could not match it to a transfer. Here is why:', 'transfer-pay' ), $order->get_order_number() ) ) . "\n\n";
echo esc_html( $reason ) . "\n\n";

echo esc_html__( 'Please check the details below, then upload a new proof:', 'transfer-pay' ) . "\n\n";

foreach ( $details as $tp_row ) {
	echo esc_html( $tp_row['label'] . ': ' . $tp_row['value'] ) . "\n";
}
echo "\n" . esc_url( $order->get_checkout_order_received_url() ) . "\n";

if ( $additional_content ) {
	echo "\n\n----------------------------------------\n\n";
	echo esc_html( wp_strip_all_tags( wptexturize( $additional_content ) ) );
	echo "\n";
}

echo "\n\n----------------------------------------\n\n";
echo wp_kses_post( apply_filters( 'woocommerce_email_footer_text', get_option( 'woocommerce_email_footer_text' ) ) );
