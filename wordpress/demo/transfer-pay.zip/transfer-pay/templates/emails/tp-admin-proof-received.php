<?php
/**
 * Admin "Payment proof received" email (HTML).
 *
 * Override by copying to yourtheme/woocommerce/emails/tp-admin-proof-received.php.
 *
 * @package Transfer_Pay
 *
 * @var WC_Order $order              Order.
 * @var array    $details            Rows of label / value.
 * @var string   $email_heading      Heading.
 * @var string   $additional_content Extra content from the email settings.
 * @var bool     $sent_to_admin      Whether sent to the shop.
 * @var bool     $plain_text         Whether plain text.
 * @var WC_Email $email              Email object.
 */

defined( 'ABSPATH' ) || exit;

$tp_reference = (string) $order->get_meta( '_tp_reference' );

do_action( 'woocommerce_email_header', $email_heading, $email ); ?>

<p>
<?php
/* translators: 1: order number, 2: customer name. */
printf( esc_html__( 'Order #%1$s from %2$s has a payment proof waiting for you.', 'transfer-pay' ), esc_html( $order->get_order_number() ), esc_html( $order->get_formatted_billing_full_name() ) );
?>
</p>

<table class="td" cellspacing="0" cellpadding="6" border="1" style="width: 100%; margin-bottom: 24px;">
	<tbody>
		<tr>
			<th class="td" scope="row" style="text-align: left;"><?php esc_html_e( 'Amount', 'transfer-pay' ); ?></th>
			<td class="td" style="text-align: left;"><?php echo esc_html( $details['amount']['value'] ); ?></td>
		</tr>
		<tr>
			<th class="td" scope="row" style="text-align: left;"><?php esc_html_e( 'Method', 'transfer-pay' ); ?></th>
			<td class="td" style="text-align: left;"><?php echo esc_html( $order->get_payment_method_title() ); ?></td>
		</tr>
		<tr>
			<th class="td" scope="row" style="text-align: left;"><?php esc_html_e( 'Reference', 'transfer-pay' ); ?></th>
			<td class="td" style="text-align: left;"><?php echo esc_html( '' !== $tp_reference ? $tp_reference : __( 'Not given', 'transfer-pay' ) ); ?></td>
		</tr>
	</tbody>
</table>

<p><?php esc_html_e( 'The proof is attached. Check it against your account, then verify or reject it from the order screen:', 'transfer-pay' ); ?></p>

<p><a href="<?php echo esc_url( $order->get_edit_order_url() ); ?>"><?php /* translators: %s: order number. */ echo esc_html( sprintf( __( 'Review order #%s', 'transfer-pay' ), $order->get_order_number() ) ); ?></a></p>

<?php
do_action( 'woocommerce_email_order_details', $order, $sent_to_admin, $plain_text, $email );

if ( $additional_content ) {
	echo wp_kses_post( wpautop( wptexturize( $additional_content ) ) );
}

do_action( 'woocommerce_email_footer', $email );
