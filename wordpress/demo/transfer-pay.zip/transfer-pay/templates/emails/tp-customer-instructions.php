<?php
/**
 * Customer "How to pay" email (HTML).
 *
 * Override by copying to yourtheme/woocommerce/emails/tp-customer-instructions.php.
 *
 * @package Transfer_Pay
 *
 * @var WC_Order                  $order              Order.
 * @var Transfer_Pay_Gateway|null $gateway            Gateway.
 * @var array                     $details            Rows of label / value.
 * @var string                    $email_heading      Heading.
 * @var string                    $additional_content Extra content from the email settings.
 * @var bool                      $sent_to_admin      Whether sent to the shop.
 * @var bool                      $plain_text         Whether plain text.
 * @var WC_Email                  $email              Email object.
 */

defined( 'ABSPATH' ) || exit;

$tp_hours = $gateway ? absint( $gateway->get_option( 'expire_hours' ) ) : 0;

do_action( 'woocommerce_email_header', $email_heading, $email ); ?>

<p>
<?php
if ( $order->get_billing_first_name() ) {
	/* translators: %s: customer first name. */
	printf( esc_html__( 'Hi %s,', 'transfer-pay' ), esc_html( $order->get_billing_first_name() ) );
} else {
	esc_html_e( 'Hi,', 'transfer-pay' );
}
?>
</p>

<p>
<?php
/* translators: 1: amount, 2: payment method name, e.g. GCash. */
printf( esc_html__( 'Thanks for your order. To complete it, send exactly %1$s via %2$s using the details below.', 'transfer-pay' ), '<strong>' . esc_html( $details['amount']['value'] ) . '</strong>', esc_html( $order->get_payment_method_title() ) );
?>
</p>

<table class="td" cellspacing="0" cellpadding="6" border="1" style="width: 100%; margin-bottom: 24px;">
	<tbody>
		<?php foreach ( $details as $tp_row ) : ?>
			<tr>
				<th class="td" scope="row" style="text-align: left;"><?php echo esc_html( $tp_row['label'] ); ?></th>
				<td class="td" style="text-align: left;"><strong><?php echo esc_html( $tp_row['value'] ); ?></strong></td>
			</tr>
		<?php endforeach; ?>
	</tbody>
</table>

<?php if ( $gateway && $gateway->get_option( 'qr_image' ) ) : ?>
	<p style="text-align: center;">
		<img src="<?php echo esc_url( $gateway->get_option( 'qr_image' ) ); ?>" alt="<?php esc_attr_e( 'Payment QR code', 'transfer-pay' ); ?>" width="200" style="width: 200px; max-width: 100%; height: auto;">
	</p>
<?php endif; ?>

<?php
if ( $gateway && $gateway->get_option( 'instructions' ) ) {
	echo wp_kses_post( wpautop( wptexturize( $gateway->get_option( 'instructions' ) ) ) );
}
?>

<p>
<?php
/* translators: %s: order number. */
printf( esc_html__( 'Please write %s in the message or notes field so we can match your payment. Then take a screenshot of the confirmation and upload it here:', 'transfer-pay' ), '<strong>' . esc_html( $order->get_order_number() ) . '</strong>' );
?>
</p>

<p><a href="<?php echo esc_url( $order->get_checkout_order_received_url() ); ?>"><?php esc_html_e( 'Upload your payment proof', 'transfer-pay' ); ?></a></p>

<?php if ( $tp_hours ) : ?>
	<p>
	<?php
	/* translators: %d: number of hours. */
	echo esc_html( sprintf( _n( 'If we do not receive your payment within %d hour, the order is cancelled automatically.', 'If we do not receive your payment within %d hours, the order is cancelled automatically.', $tp_hours, 'transfer-pay' ), $tp_hours ) );
	?>
	</p>
<?php endif; ?>

<?php
do_action( 'woocommerce_email_order_details', $order, $sent_to_admin, $plain_text, $email );

if ( $additional_content ) {
	echo wp_kses_post( wpautop( wptexturize( $additional_content ) ) );
}

do_action( 'woocommerce_email_footer', $email );
