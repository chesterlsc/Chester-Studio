<?php
/**
 * Customer "Transfer not confirmed" email (HTML).
 *
 * Override by copying to yourtheme/woocommerce/emails/tp-customer-rejected.php.
 *
 * @package Transfer_Pay
 *
 * @var WC_Order $order              Order.
 * @var array    $details            Rows of label / value.
 * @var string   $reason             Why the proof was rejected.
 * @var string   $email_heading      Heading.
 * @var string   $additional_content Extra content from the email settings.
 * @var bool     $sent_to_admin      Whether sent to the shop.
 * @var bool     $plain_text         Whether plain text.
 * @var WC_Email $email              Email object.
 */

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_email_header', $email_heading, $email ); ?>

<p>
<?php
if ( $order->get_billing_first_name() ) {
	/* translators: %s: customer first name. */
	printf( esc_html__( 'Hi %s,', 'transfer-pay' ), esc_html( $order->get_billing_first_name() ) );
} else {
	esc_html_e( 'Hi,', 'transfer-pay' );
}
?>
</p>

<p><?php /* translators: %s: order number. */ printf( esc_html__( 'We checked the payment proof for order #%s but could not match it to a transfer. Here is why:', 'transfer-pay' ), esc_html( $order->get_order_number() ) ); ?></p>

<blockquote style="margin: 0 0 16px; padding: 12px 16px; border-left: 3px solid #b5562f;"><?php echo nl2br( esc_html( $reason ) ); ?></blockquote>

<p><?php esc_html_e( 'Please check the details below, then upload a new proof:', 'transfer-pay' ); ?></p>

<table class="td" cellspacing="0" cellpadding="6" border="1" style="width: 100%; margin-bottom: 24px;">
	<tbody>
		<?php foreach ( $details as $tp_row ) : ?>
			<tr>
				<th class="td" scope="row" style="text-align: left;"><?php echo esc_html( $tp_row['label'] ); ?></th>
				<td class="td" style="text-align: left;"><strong><?php echo esc_html( $tp_row['value'] ); ?></strong></td>
			</tr>
		<?php endforeach; ?>
	</tbody>
</table>

<p><a href="<?php echo esc_url( $order->get_checkout_order_received_url() ); ?>"><?php esc_html_e( 'Upload a new payment proof', 'transfer-pay' ); ?></a></p>

<?php
if ( $additional_content ) {
	echo wp_kses_post( wpautop( wptexturize( $additional_content ) ) );
}

do_action( 'woocommerce_email_footer', $email );
