<?php
/**
 * "How to pay" panel shown on the thank-you and My Account order pages.
 *
 * Override by copying to yourtheme/woocommerce/order/tp-payment-panel.php.
 *
 * @package Transfer_Pay
 *
 * @var WC_Order             $order         The order.
 * @var Transfer_Pay_Gateway $gateway       Gateway the order was placed with.
 * @var array                $wallet        Wallet labels (title, app).
 * @var array                $details       Rows of label / value / copy value.
 * @var string               $error         Upload error message, if any.
 * @var bool                 $just_uploaded Whether the shopper just uploaded a proof.
 */

defined( 'ABSPATH' ) || exit;

$tp_order_id  = $order->get_id();
$tp_in_review = $order->has_status( 'tp-review' );
$tp_qr        = $gateway->get_option( 'qr_image' );
$tp_reason    = (string) $order->get_meta( '_tp_reject_reason' );
$tp_hours     = absint( $gateway->get_option( 'expire_hours' ) );
$tp_uploaded  = (int) $order->get_meta( '_tp_proof_uploaded_at' );
$tp_reference = (string) $order->get_meta( '_tp_reference' );
?>
<section
	id="tp-panel"
	class="tp-panel"
	aria-labelledby="tp-panel-title"
	data-tp-copied="<?php /* translators: %s: the copied item, e.g. Account name. */ esc_attr_e( '%s copied.', 'transfer-pay' ); ?>"
	data-tp-failed="<?php esc_attr_e( 'Could not copy. Please select the text and copy it yourself.', 'transfer-pay' ); ?>"
	data-tp-done="<?php esc_attr_e( 'Copied', 'transfer-pay' ); ?>"
>
	<h2 id="tp-panel-title" class="tp-panel__title">
		<?php echo esc_html( $tp_in_review ? __( 'Payment proof received', 'transfer-pay' ) : __( 'How to pay', 'transfer-pay' ) ); ?>
	</h2>

	<?php if ( $error ) : ?>
		<p class="tp-notice tp-notice--error" role="alert" tabindex="-1" data-tp-focus><?php echo esc_html( $error ); ?></p>
	<?php endif; ?>

	<?php if ( $tp_in_review ) : ?>
		<div class="tp-done" role="status" <?php echo $just_uploaded ? 'tabindex="-1" data-tp-focus' : ''; ?>>
			<p><?php esc_html_e( 'Thank you. We will check your transfer against our account and email you as soon as your order is confirmed.', 'transfer-pay' ); ?></p>
			<?php if ( $tp_uploaded ) : ?>
				<p class="tp-meta">
					<?php
					/* translators: %s: date and time the proof was uploaded. */
					echo esc_html( sprintf( __( 'Uploaded %s', 'transfer-pay' ), wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $tp_uploaded ) ) );
					if ( '' !== $tp_reference ) {
						/* translators: %s: transaction reference number. */
						echo ' &middot; ' . esc_html( sprintf( __( 'Reference %s', 'transfer-pay' ), $tp_reference ) );
					}
					?>
				</p>
			<?php endif; ?>
		</div>
	<?php else : ?>
		<?php if ( '' !== $tp_reason ) : ?>
			<div class="tp-notice tp-notice--error">
				<p><strong><?php esc_html_e( 'We could not confirm your last transfer.', 'transfer-pay' ); ?></strong></p>
				<p><?php echo nl2br( esc_html( $tp_reason ) ); ?></p>
				<p><?php esc_html_e( 'Please check the details below and upload a new proof.', 'transfer-pay' ); ?></p>
			</div>
		<?php endif; ?>

		<p class="tp-lead">
			<?php
			/* translators: 1: amount, 2: payment method name, e.g. GCash. */
			printf( esc_html__( 'Send exactly %1$s via %2$s, then upload a screenshot of the receipt below.', 'transfer-pay' ), '<strong>' . esc_html( $details['amount']['value'] ) . '</strong>', esc_html( $gateway->get_title() ) );
			?>
		</p>

		<dl class="tp-details">
			<?php foreach ( $details as $tp_key => $tp_row ) : ?>
				<div class="tp-details__row tp-details__row--<?php echo esc_attr( $tp_key ); ?>">
					<dt><?php echo esc_html( $tp_row['label'] ); ?></dt>
					<dd>
						<span class="tp-details__value"><?php echo esc_html( $tp_row['value'] ); ?></span>
						<?php if ( '' !== $tp_row['copy'] ) : ?>
							<button type="button" class="tp-copy" data-tp-copy="<?php echo esc_attr( $tp_row['copy'] ); ?>" data-tp-label="<?php echo esc_attr( $tp_row['label'] ); ?>">
								<span class="tp-copy__text"><?php esc_html_e( 'Copy', 'transfer-pay' ); ?></span><span class="tp-sr"> <?php echo esc_html( $tp_row['label'] ); ?></span>
							</button>
						<?php endif; ?>
					</dd>
				</div>
			<?php endforeach; ?>
		</dl>

		<?php if ( $tp_qr ) : ?>
			<figure class="tp-qr">
				<img src="<?php echo esc_url( $tp_qr ); ?>" alt="<?php /* translators: %s: payment method name, e.g. GCash. */ echo esc_attr( sprintf( __( 'QR code for paying by %s', 'transfer-pay' ), $gateway->get_title() ) ); ?>" width="200" height="200" loading="lazy">
				<figcaption><?php /* translators: %s: app name, e.g. your GCash app. */ echo esc_html( sprintf( __( 'Or scan this code with %s.', 'transfer-pay' ), $wallet['app'] ) ); ?></figcaption>
			</figure>
		<?php endif; ?>

		<ol class="tp-steps">
			<li><?php /* translators: 1: app name, e.g. your GCash app; 2: amount. */ echo esc_html( sprintf( __( 'Open %1$s and send exactly %2$s to the account above.', 'transfer-pay' ), $wallet['app'], $details['amount']['value'] ) ); ?></li>
			<li><?php /* translators: %s: order number. */ echo esc_html( sprintf( __( 'Write %s in the message or notes field so we can match your payment.', 'transfer-pay' ), $order->get_order_number() ) ); ?></li>
			<li><?php esc_html_e( 'Take a screenshot of the confirmation screen.', 'transfer-pay' ); ?></li>
			<li><?php esc_html_e( 'Upload it below. We confirm your order as soon as the money arrives.', 'transfer-pay' ); ?></li>
		</ol>

		<?php if ( $tp_hours ) : ?>
			<p class="tp-meta"><?php /* translators: %d: number of hours. */ echo esc_html( sprintf( _n( 'Please pay within %d hour, or the order is cancelled automatically.', 'Please pay within %d hours, or the order is cancelled automatically.', $tp_hours, 'transfer-pay' ), $tp_hours ) ); ?></p>
		<?php endif; ?>

		<?php if ( $gateway->get_option( 'instructions' ) ) : ?>
			<div class="tp-instructions"><?php echo wp_kses_post( wpautop( wptexturize( $gateway->get_option( 'instructions' ) ) ) ); ?></div>
		<?php endif; ?>
	<?php endif; ?>

	<?php if ( $tp_in_review ) : ?>
		<details class="tp-replace">
		<summary><?php esc_html_e( 'Uploaded the wrong file? Replace it', 'transfer-pay' ); ?></summary>
	<?php else : ?>
		<h3 class="tp-panel__subtitle"><?php esc_html_e( 'Upload your payment proof', 'transfer-pay' ); ?></h3>
	<?php endif; ?>

	<form class="tp-upload" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">
		<input type="hidden" name="action" value="tp_upload_proof">
		<input type="hidden" name="order_id" value="<?php echo esc_attr( $tp_order_id ); ?>">
		<input type="hidden" name="order_key" value="<?php echo esc_attr( $order->get_order_key() ); ?>">
		<?php wp_nonce_field( 'tp_upload_proof_' . $tp_order_id, 'tp_nonce' ); ?>

		<p class="tp-field">
			<label for="tp-proof-file"><?php esc_html_e( 'Receipt screenshot or PDF', 'transfer-pay' ); ?></label>
			<input type="file" id="tp-proof-file" name="tp_proof" accept=".jpg,.jpeg,.png,.webp,.pdf,image/jpeg,image/png,image/webp,application/pdf" required aria-describedby="tp-proof-hint">
			<span id="tp-proof-hint" class="tp-hint"><?php esc_html_e( 'JPG, PNG, WebP or PDF, up to 5 MB.', 'transfer-pay' ); ?></span>
		</p>

		<p class="tp-field">
			<label for="tp-proof-reference">
				<?php esc_html_e( 'Transaction reference no.', 'transfer-pay' ); ?>
				<span class="tp-hint"><?php esc_html_e( '(optional)', 'transfer-pay' ); ?></span>
			</label>
			<input type="text" id="tp-proof-reference" name="tp_reference" maxlength="64" autocomplete="off" value="<?php echo esc_attr( $tp_reference ); ?>">
		</p>

		<button type="submit" class="tp-button wp-element-button">
			<?php echo esc_html( $tp_in_review ? __( 'Replace proof', 'transfer-pay' ) : __( 'Upload proof', 'transfer-pay' ) ); ?>
		</button>
	</form>

	<?php if ( $tp_in_review ) : ?>
		</details>
	<?php endif; ?>

	<p class="tp-sr" aria-live="polite" data-tp-live></p>
</section>
