<?php
/**
 * Plugin Name:          Transfer Pay for WooCommerce
 * Plugin URI:           https://chesterstudio.space
 * Description:          GCash, Maya and bank-transfer checkout for Philippine stores, with proof-of-payment upload and one-click verification.
 * Version:              1.0.0
 * Requires at least:    6.5
 * Requires PHP:         7.4
 * Requires Plugins:     woocommerce
 * Author:               Chester Studio
 * Author URI:           https://chesterstudio.space
 * License:              GPL-2.0-or-later
 * License URI:          https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:          transfer-pay
 * WC requires at least: 8.5
 * WC tested up to:      11.2
 *
 * @package Transfer_Pay
 */

defined( 'ABSPATH' ) || exit;

define( 'TRANSFER_PAY_VERSION', '1.0.0' );
define( 'TRANSFER_PAY_FILE', __FILE__ );
define( 'TRANSFER_PAY_PATH', plugin_dir_path( __FILE__ ) );
define( 'TRANSFER_PAY_URL', plugin_dir_url( __FILE__ ) );

require_once TRANSFER_PAY_PATH . 'includes/class-transfer-pay.php';

add_action( 'before_woocommerce_init', array( 'Transfer_Pay', 'declare_compatibility' ) );
add_action( 'plugins_loaded', array( 'Transfer_Pay', 'init' ) );
