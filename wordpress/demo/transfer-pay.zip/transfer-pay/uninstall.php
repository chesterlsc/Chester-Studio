<?php
/**
 * Uninstall: remove settings. Payment proofs and order data are kept on purpose
 * (they are part of the shop's financial records); see readme.txt.
 *
 * @package Transfer_Pay
 */

defined( 'ABSPATH' ) || exit;
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

foreach ( array( 'tp_gcash', 'tp_maya', 'tp_bank', 'tp_customer_instructions', 'tp_admin_proof_received', 'tp_customer_rejected' ) as $transfer_pay_id ) {
	delete_option( 'woocommerce_' . $transfer_pay_id . '_settings' );
}
