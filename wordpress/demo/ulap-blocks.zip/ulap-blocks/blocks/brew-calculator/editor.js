/* Brew calculator: default method and servings in the sidebar, server-rendered preview. No build step. */
( function ( wp ) {
	var el = wp.element.createElement;
	var __ = wp.i18n.__;
	var methods = [
		{ value: 'pourover', label: __( 'Pour-over', 'ulap-blocks' ) },
		{ value: 'frenchpress', label: __( 'French press', 'ulap-blocks' ) },
		{ value: 'moka', label: __( 'Moka pot', 'ulap-blocks' ) },
		{ value: 'espresso', label: __( 'Espresso', 'ulap-blocks' ) },
		{ value: 'coldbrew', label: __( 'Cold brew', 'ulap-blocks' ) },
	];
	wp.blocks.registerBlockType( 'ulap/brew-calculator', {
		edit: function ( props ) {
			var a = props.attributes;
			return el(
				wp.element.Fragment,
				null,
				el(
					wp.blockEditor.InspectorControls,
					null,
					el(
						wp.components.PanelBody,
						{ title: __( 'Defaults', 'ulap-blocks' ) },
						el( wp.components.SelectControl, {
							label: __( 'Brew method', 'ulap-blocks' ),
							value: a.method,
							options: methods,
							onChange: function ( v ) { props.setAttributes( { method: v } ); },
						} ),
						el( wp.components.RangeControl, {
							label: __( 'Servings', 'ulap-blocks' ),
							value: a.servings,
							min: 1,
							max: 6,
							onChange: function ( v ) { props.setAttributes( { servings: v } ); },
						} )
					)
				),
				el( 'div', wp.blockEditor.useBlockProps(), el( wp.serverSideRender, { block: 'ulap/brew-calculator', attributes: a } ) )
			);
		},
	} );
} )( window.wp );
