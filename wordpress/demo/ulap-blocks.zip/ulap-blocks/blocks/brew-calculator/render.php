<?php
/**
 * Brew calculator: server render with Interactivity API directives.
 *
 * The first paint is computed here, so the recipe reads correctly before
 * (or without) JavaScript; view.js takes over on the client.
 *
 * @package UlapBlocks
 *
 * @var array $attributes Block attributes.
 */

defined( 'ABSPATH' ) || exit;

$ulap_methods  = ulap_blocks_brew_methods();
$ulap_method   = isset( $ulap_methods[ $attributes['method'] ] ) ? $attributes['method'] : 'pourover';
$ulap_servings = max( 1, min( 6, (int) $attributes['servings'] ) );
$ulap_m        = $ulap_methods[ $ulap_method ];

// Derived values for the first paint; view.js derives the same from context.
wp_interactivity_state(
	'ulap/brew',
	array(
		'methods'  => $ulap_methods,
		'coffee'   => $ulap_m['dose'] * $ulap_servings . ' g',
		'water'    => $ulap_m['water'] * $ulap_servings . ' ml',
		'grind'    => $ulap_m['grind'],
		'time'     => $ulap_m['time'],
		'temp'     => $ulap_m['temp'],
		'tip'      => $ulap_m['tip'],
		'serving'  => $ulap_m['serving'],
		'bag'      => sprintf( /* translators: 1: number, 2: serving name */ __( 'A 250 g bag makes about %1$d %2$s.', 'ulap-blocks' ), floor( 250 / $ulap_m['dose'] ), $ulap_m['serving'] ),
		'ratio'    => '1:' . round( $ulap_m['water'] / $ulap_m['dose'], 1 ),
		'bagLabel' => __( 'A 250 g bag makes about %1$d %2$s.', 'ulap-blocks' ),
	)
);

$ulap_uid = wp_unique_id( 'ulap-brew-' );
?>
<div
	<?php echo get_block_wrapper_attributes( array( 'class' => 'ulap-brew' ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
	data-wp-interactive="ulap/brew"
	<?php echo wp_interactivity_data_wp_context( array( 'method' => $ulap_method, 'servings' => $ulap_servings ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
>
	<div class="ulap-brew__controls">
		<p class="ulap-brew__label" id="<?php echo esc_attr( $ulap_uid ); ?>-m"><?php esc_html_e( 'Brew method', 'ulap-blocks' ); ?></p>
		<div class="ulap-brew__methods" role="group" aria-labelledby="<?php echo esc_attr( $ulap_uid ); ?>-m">
			<?php foreach ( $ulap_methods as $ulap_key => $ulap_item ) : ?>
				<button
					type="button"
					class="ulap-brew__method<?php echo $ulap_key === $ulap_method ? ' is-active' : ''; ?>"
					aria-pressed="<?php echo $ulap_key === $ulap_method ? 'true' : 'false'; ?>"
					<?php echo wp_interactivity_data_wp_context( array( 'id' => $ulap_key ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
					data-wp-on--click="actions.pick"
					data-wp-bind--aria-pressed="state.isPicked"
					data-wp-class--is-active="state.isPicked"
				><?php echo esc_html( $ulap_item['label'] ); ?></button>
			<?php endforeach; ?>
		</div>

		<label class="ulap-brew__label" for="<?php echo esc_attr( $ulap_uid ); ?>-s">
			<?php esc_html_e( 'How many', 'ulap-blocks' ); ?>
			<output data-wp-text="context.servings"><?php echo esc_html( $ulap_servings ); ?></output>
			<span data-wp-text="state.serving"><?php echo esc_html( $ulap_m['serving'] ); ?></span>
		</label>
		<input
			id="<?php echo esc_attr( $ulap_uid ); ?>-s"
			class="ulap-brew__range"
			type="range" min="1" max="6" step="1"
			value="<?php echo esc_attr( $ulap_servings ); ?>"
			data-wp-bind--value="context.servings"
			data-wp-on--input="actions.setServings"
		/>
	</div>

	<div class="ulap-brew__result" aria-live="polite">
		<div class="ulap-brew__big">
			<div><span><?php esc_html_e( 'Coffee', 'ulap-blocks' ); ?></span><strong data-wp-text="state.coffee"><?php echo esc_html( $ulap_m['dose'] * $ulap_servings . ' g' ); ?></strong></div>
			<div><span><?php esc_html_e( 'Water', 'ulap-blocks' ); ?></span><strong data-wp-text="state.water"><?php echo esc_html( $ulap_m['water'] * $ulap_servings . ' ml' ); ?></strong></div>
			<div><span><?php esc_html_e( 'Ratio', 'ulap-blocks' ); ?></span><strong data-wp-text="state.ratio"><?php echo esc_html( '1:' . round( $ulap_m['water'] / $ulap_m['dose'], 1 ) ); ?></strong></div>
		</div>
		<dl class="ulap-brew__facts">
			<div><dt><?php esc_html_e( 'Grind', 'ulap-blocks' ); ?></dt><dd data-wp-text="state.grind"><?php echo esc_html( $ulap_m['grind'] ); ?></dd></div>
			<div><dt><?php esc_html_e( 'Time', 'ulap-blocks' ); ?></dt><dd data-wp-text="state.time"><?php echo esc_html( $ulap_m['time'] ); ?></dd></div>
			<div><dt><?php esc_html_e( 'Water temp', 'ulap-blocks' ); ?></dt><dd data-wp-text="state.temp"><?php echo esc_html( $ulap_m['temp'] ); ?></dd></div>
		</dl>
		<p class="ulap-brew__tip" data-wp-text="state.tip"><?php echo esc_html( $ulap_m['tip'] ); ?></p>
		<p class="ulap-brew__bag" data-wp-text="state.bag"><?php echo esc_html( sprintf( __( 'A 250 g bag makes about %1$d %2$s.', 'ulap-blocks' ), floor( 250 / $ulap_m['dose'] ), $ulap_m['serving'] ) ); // phpcs:ignore WordPress.WP.I18n.MissingTranslatorsComment ?></p>
	</div>
</div>
