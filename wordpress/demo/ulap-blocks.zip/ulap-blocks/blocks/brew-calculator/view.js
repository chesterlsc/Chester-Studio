/**
 * Brew calculator: client side, Interactivity API.
 * Server state carries the method table; everything shown is derived from
 * the block's context ({ method, servings }), so there is one source of truth.
 */
import { store, getContext } from '@wordpress/interactivity';

const method = () => state.methods[ getContext().method ];
const servings = () => getContext().servings;

const { state } = store( 'ulap/brew', {
	state: {
		get isPicked() {
			const ctx = getContext();
			return ctx.method === ctx.id;
		},
		get coffee() {
			return `${ method().dose * servings() } g`;
		},
		get water() {
			return `${ method().water * servings() } ml`;
		},
		get ratio() {
			return `1:${ Math.round( ( method().water / method().dose ) * 10 ) / 10 }`;
		},
		get grind() {
			return method().grind;
		},
		get time() {
			return method().time;
		},
		get temp() {
			return method().temp;
		},
		get tip() {
			return method().tip;
		},
		get serving() {
			return method().serving;
		},
		get bag() {
			return state.bagLabel
				.replace( '%1$d', Math.floor( 250 / method().dose ) )
				.replace( '%2$s', method().serving );
		},
	},
	actions: {
		pick() {
			const ctx = getContext();
			ctx.method = ctx.id;
		},
		setServings( event ) {
			getContext().servings = Number( event.target.value );
		},
	},
} );
