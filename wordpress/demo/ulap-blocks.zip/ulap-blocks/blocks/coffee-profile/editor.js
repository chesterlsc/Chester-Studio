/* Coffee profile: previews the server render. No build step. */
( function ( wp ) {
	var el = wp.element.createElement;
	wp.blocks.registerBlockType( 'ulap/coffee-profile', {
		edit: function ( props ) {
			var postId = props.context && props.context.postId;
			return el(
				'div',
				wp.blockEditor.useBlockProps(),
				postId
					? el( wp.serverSideRender, { block: 'ulap/coffee-profile', attributes: props.attributes, urlQueryArgs: { post_id: postId } } )
					: el( 'p', { className: 'ulap-cp__placeholder' }, wp.i18n.__( 'Coffee profile: tasting notes, roast meter and farm facts appear here on each coffee.', 'ulap-blocks' ) )
			);
		},
	} );
} )( window.wp );
