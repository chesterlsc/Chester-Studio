<?php
/**
 * Coffee profile: server render.
 *
 * Reads the global attributes pa_roast and pa_process and the custom product
 * attributes "Tasting notes", "Farm", "Altitude" and "Variety". Renders
 * nothing for products without a roast (brew gear, gift cards).
 *
 * @package UlapBlocks
 *
 * @var array    $attributes Block attributes.
 * @var WP_Block $block      Block instance.
 */

defined( 'ABSPATH' ) || exit;

$ulap_id = $block->context['postId'] ?? get_the_ID();
if ( ! $ulap_id && isset( $_GET['post_id'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification -- read-only editor preview.
	$ulap_id = absint( $_GET['post_id'] ); // phpcs:ignore WordPress.Security.NonceVerification
}
$ulap_product = function_exists( 'wc_get_product' ) ? wc_get_product( $ulap_id ) : null;
if ( ! $ulap_product ) {
	return;
}

$ulap_roast = $ulap_product->get_attribute( 'pa_roast' );
if ( '' === $ulap_roast ) {
	return;
}

$ulap_scale = ulap_blocks_roasts();
$ulap_level = array_search( $ulap_roast, $ulap_scale, true );
$ulap_level = false === $ulap_level ? 2 : $ulap_level;
// Custom attribute values come back joined with " | " (WC_DELIMITER).
$ulap_notes = array_filter( array_map( 'trim', explode( WC_DELIMITER, $ulap_product->get_attribute( 'tasting-notes' ) ) ) );
$ulap_facts = array_filter(
	array(
		__( 'Farm', 'ulap-blocks' )     => $ulap_product->get_attribute( 'farm' ),
		__( 'Altitude', 'ulap-blocks' ) => $ulap_product->get_attribute( 'altitude' ),
		__( 'Process', 'ulap-blocks' )  => $ulap_product->get_attribute( 'pa_process' ),
		__( 'Variety', 'ulap-blocks' )  => $ulap_product->get_attribute( 'variety' ),
	)
);
?>
<div <?php echo get_block_wrapper_attributes( array( 'style' => '--ulap-level:' . ( $ulap_level + 1 ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>>
	<?php if ( $ulap_notes ) : ?>
		<p class="ulap-cp__notes">
			<span class="ulap-cp__label"><?php esc_html_e( 'Tastes like', 'ulap-blocks' ); ?></span>
			<?php foreach ( $ulap_notes as $ulap_i => $ulap_note ) : ?>
				<em><?php echo esc_html( $ulap_i ? strtolower( $ulap_note ) : $ulap_note ); ?></em><?php echo $ulap_i < count( $ulap_notes ) - 1 ? ', ' : ''; ?>
			<?php endforeach; ?>
		</p>
	<?php endif; ?>

	<div class="ulap-cp__meter">
		<span class="ulap-cp__label" aria-hidden="true"><?php esc_html_e( 'Roast', 'ulap-blocks' ); ?></span>
		<ol class="ulap-cp__scale" role="img" aria-label="<?php echo esc_attr( sprintf( /* translators: 1: roast name, 2: position, 3: steps */ __( 'Roast: %1$s, %2$d of %3$d', 'ulap-blocks' ), $ulap_roast, $ulap_level + 1, count( $ulap_scale ) ) ); ?>">
			<?php foreach ( $ulap_scale as $ulap_i => $ulap_step ) : ?>
				<li class="<?php echo esc_attr( $ulap_i === $ulap_level ? 'is-current' : ( $ulap_i < $ulap_level ? 'is-on' : '' ) ); ?>"><span><?php echo esc_html( $ulap_step ); ?></span></li>
			<?php endforeach; ?>
		</ol>
	</div>

	<?php if ( $ulap_facts ) : ?>
		<dl class="ulap-cp__facts">
			<?php foreach ( $ulap_facts as $ulap_term => $ulap_value ) : ?>
				<div><dt><?php echo esc_html( $ulap_term ); ?></dt><dd><?php echo esc_html( $ulap_value ); ?></dd></div>
			<?php endforeach; ?>
		</dl>
	<?php endif; ?>
</div>
