<?php
/**
 * Plugin Name:       Ulap Blocks
 * Plugin URI:        https://chesterstudio.space/wordpress/
 * Description:       Site blocks for Ulap Coffee Roasters: a coffee profile read from WooCommerce product attributes, and an interactive brew calculator built on the Interactivity API.
 * Version:           1.0.0
 * Requires at least: 6.6
 * Requires PHP:      7.4
 * Requires Plugins:  woocommerce
 * Author:            Chester Studio
 * Author URI:        https://chesterstudio.space
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       ulap-blocks
 *
 * @package UlapBlocks
 */

defined( 'ABSPATH' ) || exit;

/*
 * Blocks ship without a build step: block.json points at plain ES5/ESM files
 * and hand-written *.asset.php files declare their dependencies.
 */
add_action(
	'init',
	function () {
		register_block_type( __DIR__ . '/blocks/coffee-profile' );
		register_block_type( __DIR__ . '/blocks/brew-calculator' );
	}
);

/**
 * The roast scale, lightest first. Shared by the coffee profile and anything
 * else that needs to place a roast on the meter.
 *
 * @return string[]
 */
function ulap_blocks_roasts() {
	return array( 'Light', 'Medium-light', 'Medium', 'Medium-dark', 'Dark' );
}

/**
 * Brew methods for the calculator, per serving.
 *
 * @return array<string, array<string, mixed>>
 */
function ulap_blocks_brew_methods() {
	return array(
		'pourover'    => array(
			'label'   => __( 'Pour-over', 'ulap-blocks' ),
			'serving' => __( 'mugs (250 ml)', 'ulap-blocks' ),
			'dose'    => 15,
			'water'   => 250,
			'grind'   => __( 'Medium-fine, like table salt', 'ulap-blocks' ),
			'time'    => __( '3:00 to 3:30', 'ulap-blocks' ),
			'temp'    => '93 °C',
			'tip'     => __( 'Bloom with twice the coffee’s weight in water for 30 seconds, then pour in slow circles.', 'ulap-blocks' ),
		),
		'frenchpress' => array(
			'label'   => __( 'French press', 'ulap-blocks' ),
			'serving' => __( 'mugs (250 ml)', 'ulap-blocks' ),
			'dose'    => 17,
			'water'   => 250,
			'grind'   => __( 'Coarse, like breadcrumbs', 'ulap-blocks' ),
			'time'    => __( '4:00, then press', 'ulap-blocks' ),
			'temp'    => '94 °C',
			'tip'     => __( 'Break the crust at four minutes, skim the foam, and press gently.', 'ulap-blocks' ),
		),
		'moka'        => array(
			'label'   => __( 'Moka pot', 'ulap-blocks' ),
			'serving' => __( 'moka cups (50 ml)', 'ulap-blocks' ),
			'dose'    => 6,
			'water'   => 50,
			'grind'   => __( 'Fine, a little coarser than espresso', 'ulap-blocks' ),
			'time'    => __( 'Off the heat at the first gurgle', 'ulap-blocks' ),
			'temp'    => __( 'Start with hot water', 'ulap-blocks' ),
			'tip'     => __( 'Fill the basket level without tamping, and keep the flame low.', 'ulap-blocks' ),
		),
		'espresso'    => array(
			'label'   => __( 'Espresso', 'ulap-blocks' ),
			'serving' => __( 'double shots', 'ulap-blocks' ),
			'dose'    => 18,
			'water'   => 36,
			'grind'   => __( 'Fine, like powdered sugar', 'ulap-blocks' ),
			'time'    => __( '25 to 30 seconds', 'ulap-blocks' ),
			'temp'    => '93 °C',
			'tip'     => __( '18 g in, 36 g out. Grind finer if it runs fast, coarser if it chokes.', 'ulap-blocks' ),
		),
		'coldbrew'    => array(
			'label'   => __( 'Cold brew', 'ulap-blocks' ),
			'serving' => __( 'glasses (250 ml, diluted 1:1)', 'ulap-blocks' ),
			'dose'    => 16,
			'water'   => 125,
			'grind'   => __( 'Extra coarse', 'ulap-blocks' ),
			'time'    => __( '14 to 16 hours in the fridge', 'ulap-blocks' ),
			'temp'    => __( 'Cold water', 'ulap-blocks' ),
			'tip'     => __( 'Strain, then top each glass with the same amount of water or milk over ice.', 'ulap-blocks' ),
		),
	);
}
