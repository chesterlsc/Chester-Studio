<?php
/**
 * Plugin Name: Ulap Demo Outbox
 * Description: Demo only. Catches every email WordPress tries to send and lists it under Tools → Demo outbox, so the store's emails can be read without a mail server. Never use on a live shop.
 * Version:     1.0.0
 * Author:      Chester Studio
 * License:     GPL-2.0-or-later
 *
 * setup.php copies this into mu-plugins for the Playground demo.
 *
 * @package Ulap
 */

defined( 'ABSPATH' ) || exit;

const ULAP_OUTBOX = 'ulap_demo_outbox';

// Store the message instead of sending it. Returning true tells WordPress it went out.
add_filter(
	'pre_wp_mail',
	function ( $return, $atts ) {
		$mail = array(
			'to'      => implode( ', ', (array) $atts['to'] ),
			'subject' => (string) $atts['subject'],
			'body'    => (string) $atts['message'],
			'html'    => false !== stripos( implode( "\n", (array) $atts['headers'] ), 'text/html' ) || false !== stripos( (string) $atts['message'], '<html' ),
			'time'    => time(),
			'files'   => array_map( 'basename', (array) $atts['attachments'] ),
		);
		$box = get_option( ULAP_OUTBOX, array() );
		array_unshift( $box, $mail );
		update_option( ULAP_OUTBOX, array_slice( $box, 0, 40 ), false );
		return true;
	},
	10,
	2
);

add_action(
	'admin_menu',
	function () {
		add_management_page( __( 'Demo outbox', 'ulap' ), __( 'Demo outbox', 'ulap' ), 'manage_woocommerce', 'ulap-outbox', 'ulap_render_outbox' );
	}
);

/**
 * Tools → Demo outbox: newest first, the selected email rendered in a sandboxed frame.
 */
function ulap_render_outbox() {
	$box = get_option( ULAP_OUTBOX, array() );
	$sel = isset( $_GET['mail'] ) ? absint( $_GET['mail'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification -- read-only view.
	echo '<div class="wrap"><h1>' . esc_html__( 'Demo outbox', 'ulap' ) . '</h1>';
	echo '<p>' . esc_html__( 'This demo has no mail server, so every email the store sends lands here instead.', 'ulap' ) . '</p>';
	if ( ! $box ) {
		echo '<p><em>' . esc_html__( 'Nothing sent yet. Place an order on the shop to see the emails it sends.', 'ulap' ) . '</em></p></div>';
		return;
	}
	echo '<div style="display:grid;grid-template-columns:minmax(260px,340px) 1fr;gap:20px;align-items:start">';
	echo '<ul style="margin:0;background:#fff;border:1px solid #dcdcde">';
	foreach ( $box as $i => $mail ) {
		$url = add_query_arg( array( 'page' => 'ulap-outbox', 'mail' => $i ), admin_url( 'tools.php' ) );
		printf(
			'<li style="margin:0;border-bottom:1px solid #f0f0f1%s"><a href="%s" style="display:block;padding:10px 12px;text-decoration:none"><strong style="display:block">%s</strong><span style="color:#646970">%s · %s</span></a></li>',
			$i === $sel ? ';background:#f0f6fc' : '',
			esc_url( $url ),
			esc_html( $mail['subject'] ),
			esc_html( $mail['to'] ),
			esc_html( human_time_diff( $mail['time'] ) . ' ' . __( 'ago', 'ulap' ) )
		);
	}
	echo '</ul>';
	$mail = $box[ $sel ] ?? $box[0];
	echo '<div style="background:#fff;border:1px solid #dcdcde">';
	printf( '<p style="margin:0;padding:12px 16px;border-bottom:1px solid #f0f0f1"><strong>%s</strong><br>%s %s%s</p>', esc_html( $mail['subject'] ), esc_html__( 'To:', 'ulap' ), esc_html( $mail['to'] ), $mail['files'] ? esc_html( ' · ' . __( 'Attached:', 'ulap' ) . ' ' . implode( ', ', $mail['files'] ) ) : '' );
	if ( $mail['html'] ) {
		// sandbox="" : the email renders as a document with no scripts and no access to wp-admin.
		printf( '<iframe sandbox="" srcdoc="%s" style="width:100%%;height:78vh;border:0"></iframe>', esc_attr( $mail['body'] ) );
	} else {
		printf( '<pre style="margin:0;padding:16px;white-space:pre-wrap">%s</pre>', esc_html( $mail['body'] ) );
	}
	echo '</div></div></div>';
}
