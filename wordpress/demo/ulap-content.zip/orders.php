<?php
/**
 * Sample orders: one at each step of the Transfer Pay flow, so wp-admin shows
 * the whole story the moment the demo opens. Customers and addresses are
 * invented; the receipt image is a stamped DEMO placeholder.
 *
 * Uses the plugin's own API (save_proof, verify_order, reject_order) so the
 * notes, statuses and meta are exactly what a real shopper would produce.
 *
 * @package Ulap
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Transfer_Pay_Proof' ) ) {
	return;
}

$ulap_gateways = WC()->payment_gateways()->payment_gateways();

/**
 * The variation of a coffee for a bag size, or the product itself.
 *
 * @param string $slug Product slug.
 * @param string $size Size term slug, e.g. '250-g'.
 * @return WC_Product|null
 */
function ulap_sample_item( $slug, $size = '' ) {
	$post = get_page_by_path( $slug, OBJECT, 'product' );
	if ( ! $post ) {
		return null;
	}
	$product = wc_get_product( $post->ID );
	if ( $size && $product->is_type( 'variable' ) ) {
		$variation_id = ( new WC_Product_Data_Store_CPT() )->find_matching_product_variation( $product, array( 'attribute_pa_size' => $size ) );
		return $variation_id ? wc_get_product( $variation_id ) : null;
	}
	return $product;
}

$ulap_samples = array(
	array(
		'name'   => array( 'Bea', 'Santos' ),
		'city'   => array( 'Quezon City', '00', '1108', '45 Katipunan Avenue' ),
		'items'  => array( array( 'sagada-heirloom', '250-g', 1 ), array( 'drip-bags', '', 1 ) ),
		'wallet' => 'tp_gcash',
		'hours'  => 3,
		'step'   => 'awaiting',
	),
	array(
		'name'   => array( 'Miguel', 'Reyes' ),
		'city'   => array( 'Makati', '00', '1226', '18 Jupiter Street' ),
		'items'  => array( array( 'atok-highlands', '500-g', 1 ), array( 'batangas-barako', '250-g', 1 ) ),
		'wallet' => 'tp_gcash',
		'hours'  => 5,
		'step'   => 'review',
	),
	array(
		'name'   => array( 'Ana', 'Villanueva' ),
		'city'   => array( 'Cebu City', 'CEB', '6000', '7 Gorordo Avenue' ),
		'items'  => array( array( 'ulap-house-blend', '1-kg', 1 ) ),
		'wallet' => 'tp_maya',
		'hours'  => 26,
		'step'   => 'verified',
	),
	array(
		'name'   => array( 'Paolo', 'Dizon' ),
		'city'   => array( 'Baguio City', 'BEN', '2600', '3 Leonard Wood Road' ),
		'items'  => array( array( 'mountain-trio', '', 1 ), array( 'enamel-mug', '', 2 ) ),
		'wallet' => 'tp_bank',
		'hours'  => 74,
		'step'   => 'completed',
	),
	array(
		'name'   => array( 'Carla', 'Mendoza' ),
		'city'   => array( 'Davao City', 'DAS', '8000', '21 Juna Avenue' ),
		'items'  => array( array( 'mt-apo-sunrise', '250-g', 2 ) ),
		'wallet' => 'tp_maya',
		'hours'  => 30,
		'step'   => 'rejected',
	),
);

foreach ( $ulap_samples as $ulap_s ) {
	$ulap_order = wc_create_order();
	foreach ( $ulap_s['items'] as $ulap_item ) {
		$ulap_product = ulap_sample_item( $ulap_item[0], $ulap_item[1] );
		if ( $ulap_product ) {
			$ulap_order->add_product( $ulap_product, $ulap_item[2] );
		}
	}
	$ulap_address = array(
		'first_name' => $ulap_s['name'][0],
		'last_name'  => $ulap_s['name'][1],
		'address_1'  => $ulap_s['city'][3],
		'city'       => $ulap_s['city'][0],
		'state'      => $ulap_s['city'][1],
		'postcode'   => $ulap_s['city'][2],
		'country'    => 'PH',
		'email'      => strtolower( $ulap_s['name'][0] ) . '@example.com',
		'phone'      => '0900 000 0000',
	);
	$ulap_order->set_address( $ulap_address, 'billing' );
	$ulap_order->set_address( $ulap_address, 'shipping' );

	$ulap_ship = new WC_Order_Item_Shipping();
	$ulap_metro = '00' === $ulap_s['city'][1];
	$ulap_ship->set_method_title( $ulap_metro ? 'Standard · Next-day delivery' : 'Standard · 3 to 5 days' );
	$ulap_ship->set_method_id( 'flat_rate' );
	$ulap_ship->set_total( $ulap_metro ? 99 : 199 );
	$ulap_order->add_item( $ulap_ship );

	$ulap_order->set_payment_method( $ulap_gateways[ $ulap_s['wallet'] ] );
	$ulap_order->calculate_totals();
	$ulap_order->set_date_created( time() - $ulap_s['hours'] * HOUR_IN_SECONDS );
	$ulap_order->save();
	$ulap_order->update_status( 'tp-awaiting', __( 'Waiting for the shopper’s transfer.', 'ulap' ) );

	if ( 'awaiting' === $ulap_s['step'] ) {
		continue;
	}

	$ulap_tmp = wp_tempnam( 'demo-proof.jpg' );
	copy( __DIR__ . '/images/demo-proof.jpg', $ulap_tmp );
	Transfer_Pay_Proof::save_proof( $ulap_order, $ulap_tmp, 'demo-proof.jpg', 'DEMO ' . wp_rand( 1000, 9999 ) . ' ' . wp_rand( 1000, 9999 ) );
	wp_delete_file( $ulap_tmp );

	$ulap_order = wc_get_order( $ulap_order->get_id() );
	if ( 'verified' === $ulap_s['step'] || 'completed' === $ulap_s['step'] ) {
		Transfer_Pay_Admin::verify_order( $ulap_order );
		if ( 'completed' === $ulap_s['step'] ) {
			wc_get_order( $ulap_order->get_id() )->update_status( 'completed', __( 'Delivered.', 'ulap' ) );
		}
	} elseif ( 'rejected' === $ulap_s['step'] ) {
		Transfer_Pay_Admin::reject_order( $ulap_order, __( 'The transfer was ₱100 short of the order total. Please send the remaining ₱100 and upload both receipts.', 'ulap' ) );
	}
}
