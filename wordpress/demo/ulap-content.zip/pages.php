<?php
/**
 * Page content for the Ulap store, as block markup.
 *
 * @package Ulap
 */

defined( 'ABSPATH' ) || exit;

/**
 * Serialize one block. Attributes are JSON-encoded the way the editor does.
 *
 * @param string $name  Block name without the core/ prefix for core blocks.
 * @param array  $attrs Block attributes.
 * @param string $html  Inner HTML (already escaped).
 * @return string
 */
function ulap_block( $name, $attrs = array(), $html = '' ) {
	$json = $attrs ? ' ' . wp_json_encode( $attrs, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP ) : '';
	return '' === $html ? "<!-- wp:{$name}{$json} /-->\n" : "<!-- wp:{$name}{$json} -->\n{$html}\n<!-- /wp:{$name} -->\n";
}

function ulap_p( $text, $class = '' ) {
	return ulap_block( 'paragraph', $class ? array( 'className' => $class ) : array(), '<p' . ( $class ? ' class="' . esc_attr( $class ) . '"' : '' ) . '>' . $text . '</p>' );
}

function ulap_h( $text, $level = 2, $size = '' ) {
	$attrs = 2 === $level ? array() : array( 'level' => $level );
	$class = 'wp-block-heading';
	if ( $size ) {
		$attrs['fontSize'] = $size;
		$class            .= ' has-' . $size . '-font-size';
	}
	return ulap_block( 'heading', $attrs, "<h{$level} class=\"{$class}\">" . esc_html( $text ) . "</h{$level}>" );
}

function ulap_details( $summary, $body ) {
	return ulap_block( 'details', array(), '<details class="wp-block-details"><summary>' . esc_html( $summary ) . "</summary>\n" . ulap_p( esc_html( $body ) ) . '</details>' );
}

/**
 * All pages, keyed by slug.
 *
 * @param array $data products.json.
 * @return array<string, array{title:string, content:string, template?:string}>
 */
function ulap_pages( $data ) {
	$pages = array();

	$pages['home'] = array(
		'title'   => 'Home',
		'content' => '',
	);

	// ---- Origins: one section per single-origin coffee, highest farm first.
	$origins = array_filter( $data['products'], fn( $p ) => 'Single origin' === $p['category'] );
	usort( $origins, fn( $a, $b ) => $b['altitude'] <=> $a['altitude'] );
	$c  = ulap_p( esc_html__( 'Eight farms, two islands, one roaster. Here is where each coffee grows, how high, and what that does to the cup.', 'ulap' ), 'ulap-lede' );
	$c .= ulap_block( 'pattern', array( 'slug' => 'ulap/origins-chart' ) );
	foreach ( $origins as $p ) {
		$product = get_page_by_path( $p['slug'], OBJECT, 'product' );
		$img_id  = $product ? (int) ( wc_get_product( $product->ID )->get_gallery_image_ids()[0] ?? 0 ) : 0;
		$img     = $img_id ? ulap_block( 'image', array( 'id' => $img_id, 'sizeSlug' => 'large', 'linkDestination' => 'none', 'className' => 'ulap-rounded' ), '<figure class="wp-block-image size-large ulap-rounded"><img src="' . esc_url( wp_get_attachment_image_url( $img_id, 'large' ) ) . '" alt="' . esc_attr( 'Tasting card for ' . $p['name'] ) . '" class="wp-image-' . $img_id . '"/></figure>' ) : '';
		$text    = ulap_p( esc_html( strtoupper( $p['farm'] ) . ' · ' . number_format( $p['altitude'] ) . ' MASL · ' . strtoupper( $p['process'] ) ), 'is-style-eyebrow' )
			. ulap_h( $p['name'], 2, 'x-large' )
			. ulap_p( esc_html( $p['desc'] ) )
			. ulap_p( '<em>' . esc_html( implode( ', ', array_map( fn( $n, $i ) => $i ? strtolower( $n ) : $n, $p['notes'], array_keys( $p['notes'] ) ) ) ) . '</em>', 'ulap-notes' )
			. ( $product ? ulap_p( '<a href="' . esc_url( get_permalink( $product ) ) . '">' . esc_html( sprintf( 'Shop %s', $p['name'] ) ) . '</a>', 'ulap-arrow-link' ) : '' );
		$c .= ulap_block(
			'columns',
			array(
				'verticalAlignment' => 'center',
				'align'             => 'wide',
				'className'         => 'ulap-origin',
			),
			'<div class="wp-block-columns alignwide are-vertically-aligned-center ulap-origin">'
			. ulap_block( 'column', array( 'verticalAlignment' => 'center', 'width' => '42%' ), '<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:42%">' . $img . '</div>' )
			. ulap_block( 'column', array( 'verticalAlignment' => 'center' ), '<div class="wp-block-column is-vertically-aligned-center">' . $text . '</div>' )
			. '</div>'
		);
	}
	$pages['origins'] = array(
		'title'   => 'Origins',
		'content' => $c,
	);

	// ---- Brew guide.
	$c       = ulap_p( esc_html__( 'Good beans forgive a lot, but the ratio doesn’t. Pick your brewer, tell us how many cups, and weigh it out.', 'ulap' ), 'ulap-lede' );
	$c      .= ulap_block( 'ulap/brew-calculator', array( 'align' => 'wide' ) );
	$methods = array(
		'Pour-over'    => array( 'Rinse the paper filter with hot water and discard it.', 'Add 15 g of coffee per mug, ground medium-fine, and level the bed.', 'Bloom with 30 g of water for 30 seconds.', 'Pour the rest in slow circles until you reach 250 g per mug, finishing by 3:30.' ),
		'French press' => array( 'Add 17 g of coarse coffee per mug.', 'Pour all the water at 94 °C and stir once.', 'Wait four minutes, break the crust and skim the foam.', 'Press gently and pour it all out so it doesn’t over-brew.' ),
		'Moka pot'     => array( 'Fill the base with hot water up to the valve.', 'Fill the basket level with fine coffee. Don’t tamp.', 'Brew on low heat with the lid open.', 'Take it off the heat at the first gurgle and cool the base under the tap.' ),
		'Cold brew'    => array( 'Coarsely grind 16 g of coffee per glass.', 'Stir it into 125 ml of cold water per glass.', 'Cover and leave it in the fridge for 14 to 16 hours.', 'Strain, then dilute 1:1 with water or milk over ice.' ),
	);
	foreach ( $methods as $name => $steps ) {
		$c .= ulap_h( $name, 3, 'large' );
		$c .= ulap_block( 'list', array( 'ordered' => true ), '<ol class="wp-block-list">' . implode( '', array_map( fn( $s ) => ulap_block( 'list-item', array(), '<li>' . esc_html( $s ) . '</li>' ), $steps ) ) . '</ol>' );
	}
	$pages['brew-guide'] = array(
		'title'   => 'Brew guide',
		'content' => $c,
	);

	// ---- Our story.
	$c  = ulap_p( esc_html__( 'Ulap means cloud. Above about a thousand metres, the farms that grow our coffee spend most afternoons inside one.', 'ulap' ), 'ulap-lede' );
	$c .= ulap_p( esc_html__( 'We roast on Session Road in Baguio, twice a week, in batches small enough to taste every one. We buy from farms we can drive to, pay for quality, and print the farm, the altitude and the process on every bag so you know exactly what you are drinking.', 'ulap' ) );
	$c .= ulap_block( 'quote', array(), '<blockquote class="wp-block-quote">' . ulap_p( esc_html__( 'Philippine coffee doesn’t need to be dressed up. It needs to be roasted with care and sent out fresh.', 'ulap' ) ) . '</blockquote>' );
	$c .= ulap_p( esc_html__( 'Arabica from the Cordillera and the Mindanao highlands. Liberica from Batangas, the barako our parents grew up on. Excelsa from Amadeo, a coffee most people have never tried. That’s the whole shelf.', 'ulap' ) );
	$pages['our-story'] = array(
		'title'   => 'Our story',
		'content' => $c,
	);

	// ---- Shipping and FAQ.
	$faq = array(
		'When do you roast?'                          => 'Every Tuesday and Friday. Orders placed by 6 PM the day before go into that batch and ship within 48 hours of roasting.',
		'How much is shipping?'                       => 'Metro Manila ₱99 (next day), rest of Luzon ₱149 (2 to 3 days), Visayas and Mindanao ₱199 (3 to 5 days). Free nationwide on orders over ₱1,500.',
		'How do I pay with GCash or Maya?'            => 'Choose GCash or Maya at checkout. Your order page shows our account, a QR code and the exact amount. Send it with your order number in the message, then upload the screenshot on the same page. We confirm it the same day.',
		'How long do I have to pay?'                  => 'We hold your order for 48 hours. If no payment arrives by then it cancels on its own and the stock goes back on the shelf.',
		'Which grind should I choose?'                => 'Whole bean keeps longest. If you don’t have a grinder, pick your brewer and we’ll grind for it on roast day.',
		'How should I store the beans?'               => 'Keep the bag sealed, away from light and heat. Not in the fridge. Coffee is at its best 7 to 30 days after roasting.',
		'Do you sell wholesale to cafés?'             => 'Yes. Send us a message with your café, your volume and the brewers you use, and we will put together a tasting box.',
	);
	$c = '';
	foreach ( $faq as $q => $a ) {
		$c .= ulap_details( $q, $a );
	}
	$pages['shipping-faq'] = array(
		'title'   => 'Shipping & FAQ',
		'content' => $c,
	);

	return $pages;
}
