<?php
/**
 * Builds the Ulap store on a fresh WordPress + WooCommerce install:
 * settings, attributes, categories, products with variations and images,
 * shipping zones, pages, payment settings and a few sample orders.
 *
 * Run once, after WooCommerce, the Ulap theme and both plugins are active:
 *   require '/wordpress/wp-load.php'; require '.../content/setup.php';
 *
 * Everything is read from products.json beside this file, the same data the
 * product art is drawn from.
 *
 * @package Ulap
 */

defined( 'ABSPATH' ) || exit;

require_once ABSPATH . 'wp-admin/includes/media.php';
require_once ABSPATH . 'wp-admin/includes/file.php';
require_once ABSPATH . 'wp-admin/includes/image.php';

$ulap_data = json_decode( file_get_contents( __DIR__ . '/products.json' ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions

// WooCommerce finishes new-store setup (HPOS on) at the first wp-admin visit.
// Run it now so the sample orders are written to the custom order tables.
wp_set_current_user( 1 );
WC_Install::newly_installed();

// Demo only: no mail server in Playground, so emails go to Tools → Demo outbox.
wp_mkdir_p( WPMU_PLUGIN_DIR );
copy( __DIR__ . '/demo-outbox.php', WPMU_PLUGIN_DIR . '/ulap-demo-outbox.php' );
require_once WPMU_PLUGIN_DIR . '/ulap-demo-outbox.php';

/*
 * ---- Site and store settings
 */
$ulap_options = array(
	'blogname'                               => 'Ulap',
	'blogdescription'                        => 'Coffee Roasters',
	'timezone_string'                        => 'Asia/Manila',
	'date_format'                            => 'j F Y',
	'permalink_structure'                    => '/%postname%/',
	'woocommerce_currency'                   => 'PHP',
	'woocommerce_price_num_decimals'         => '0',
	'woocommerce_currency_pos'               => 'left',
	'woocommerce_default_country'            => 'PH:BEN',
	'woocommerce_store_address'              => '12 Session Road',
	'woocommerce_store_city'                 => 'Baguio City',
	'woocommerce_store_postcode'             => '2600',
	'woocommerce_allowed_countries'          => 'specific',
	'woocommerce_specific_allowed_countries' => array( 'PH' ),
	'woocommerce_ship_to_countries'          => '',
	'woocommerce_calc_taxes'                 => 'no',
	'woocommerce_enable_reviews'             => 'no',
	'woocommerce_enable_guest_checkout'      => 'yes',
	'woocommerce_weight_unit'                => 'kg',
	'woocommerce_coming_soon'                => 'no',
	'woocommerce_store_pages_only'           => 'no',
	'woocommerce_allow_tracking'             => 'no',
	'woocommerce_show_marketplace_suggestions' => 'no',
	'woocommerce_task_list_hidden'           => 'yes',
	'woocommerce_onboarding_profile'         => array( 'skipped' => true ),
	'woocommerce_email_from_name'            => 'Ulap Coffee Roasters',
	'woocommerce_email_base_color'           => '#b5562f',
	'woocommerce_email_background_color'     => '#f5f0e8',
	'woocommerce_email_body_background_color' => '#fbf8f3',
	'woocommerce_email_text_color'           => '#1e1915',
	'woocommerce_email_footer_text'          => 'Ulap Coffee Roasters · Baguio City · A concept store by Chester Studio',
);
foreach ( $ulap_options as $ulap_key => $ulap_value ) {
	update_option( $ulap_key, $ulap_value );
}
flush_rewrite_rules();

// Only the transfer gateways and cash on delivery are offered.
foreach ( array( 'bacs', 'cheque', 'cod' ) as $ulap_gw ) {
	$ulap_settings            = get_option( "woocommerce_{$ulap_gw}_settings", array() );
	$ulap_settings['enabled'] = 'no';
	update_option( "woocommerce_{$ulap_gw}_settings", $ulap_settings );
}

/*
 * ---- Media
 */
function ulap_import_image( $file, $alt ) {
	$path = __DIR__ . '/images/' . $file;
	if ( ! file_exists( $path ) ) {
		return 0;
	}
	$tmp = wp_tempnam( $file );
	copy( $path, $tmp );
	$id = media_handle_sideload( array( 'name' => $file, 'tmp_name' => $tmp ), 0, $alt );
	if ( is_wp_error( $id ) ) {
		wp_delete_file( $tmp );
		return 0;
	}
	update_post_meta( $id, '_wp_attachment_image_alt', $alt );
	return $id;
}

/*
 * ---- Global attributes: filterable in the shop, and the variation axes
 */
$ulap_attr_terms = array(
	'origin'  => array( 'label' => 'Origin', 'terms' => array() ),
	'roast'   => array( 'label' => 'Roast', 'terms' => array( 'Light', 'Medium-light', 'Medium', 'Medium-dark', 'Dark' ) ),
	'process' => array( 'label' => 'Process', 'terms' => array( 'Washed', 'Honey', 'Natural' ) ),
	'size'    => array( 'label' => 'Size', 'terms' => wp_list_pluck( $ulap_data['sizes'], 'name' ) ),
	'grind'   => array( 'label' => 'Grind', 'terms' => $ulap_data['grinds'] ),
);
foreach ( $ulap_data['products'] as $ulap_p ) {
	if ( ! empty( $ulap_p['origin'] ) && 'Blends' !== $ulap_p['category'] ) {
		$ulap_attr_terms['origin']['terms'][] = $ulap_p['origin'];
	}
}
$ulap_attr_terms['origin']['terms'] = array_values( array_unique( $ulap_attr_terms['origin']['terms'] ) );

foreach ( $ulap_attr_terms as $ulap_slug => $ulap_attr ) {
	$ulap_taxonomy = wc_attribute_taxonomy_name( $ulap_slug );
	if ( ! wc_attribute_taxonomy_id_by_name( $ulap_slug ) ) {
		wc_create_attribute(
			array(
				'name'         => $ulap_attr['label'],
				'slug'         => $ulap_slug,
				'type'         => 'select',
				'order_by'     => 'menu_order',
				'has_archives' => false,
			)
		);
	}
	// Attributes created in this request aren't registered yet.
	if ( ! taxonomy_exists( $ulap_taxonomy ) ) {
		register_taxonomy( $ulap_taxonomy, array( 'product', 'product_variation' ), array( 'hierarchical' => false, 'show_ui' => false, 'query_var' => true, 'rewrite' => false ) );
	}
	foreach ( $ulap_attr['terms'] as $ulap_i => $ulap_term ) {
		$ulap_found = term_exists( $ulap_term, $ulap_taxonomy );
		$ulap_tid   = $ulap_found ? $ulap_found['term_id'] : wp_insert_term( $ulap_term, $ulap_taxonomy )['term_id'];
		update_term_meta( $ulap_tid, 'order', $ulap_i );
	}
}

$ulap_term_slug = function ( $taxonomy, $name ) {
	$term = get_term_by( 'name', $name, $taxonomy );
	return $term ? $term->slug : sanitize_title( $name );
};
$ulap_term_id   = function ( $taxonomy, $name ) {
	$term = get_term_by( 'name', $name, $taxonomy );
	return $term ? (int) $term->term_id : 0;
};

/*
 * ---- Categories
 */
$ulap_cats = array(
	'Single origin' => 'One farm, one harvest. Arabica from the Cordillera and Mindanao highlands, and the Liberica and Excelsa of Batangas and Cavite.',
	'Blends'        => 'Built for espresso and milk, good from any brewer.',
	'Gift sets'     => 'Samplers and sets for the coffee person in your life.',
	'Drip bags'     => 'Single-cup filter bags for the office, the road and the mountain.',
	'Brew gear'     => 'The few tools we actually use every morning.',
);
$ulap_cat_ids = array();
foreach ( $ulap_cats as $ulap_name => $ulap_desc ) {
	$ulap_found                = term_exists( $ulap_name, 'product_cat' );
	$ulap_cat_ids[ $ulap_name ] = $ulap_found ? (int) $ulap_found['term_id'] : (int) wp_insert_term( $ulap_name, 'product_cat', array( 'description' => $ulap_desc ) )['term_id'];
}

/*
 * ---- Products
 */
$ulap_attribute = function ( $name, $options, $visible = true, $variation = false, $taxonomy = true ) use ( $ulap_term_id ) {
	$a = new WC_Product_Attribute();
	if ( $taxonomy ) {
		$tax = wc_attribute_taxonomy_name( $name );
		$a->set_id( wc_attribute_taxonomy_id_by_name( $name ) );
		$a->set_name( $tax );
		$a->set_options( array_filter( array_map( fn( $o ) => $ulap_term_id( $tax, $o ), (array) $options ) ) );
	} else {
		$a->set_name( $name );
		$a->set_options( (array) $options );
	}
	$a->set_visible( $visible );
	$a->set_variation( $variation );
	return $a;
};

$ulap_html = fn( $text ) => '<p>' . esc_html( $text ) . '</p>';

foreach ( $ulap_data['products'] as $ulap_p ) {
	if ( get_page_by_path( $ulap_p['slug'], OBJECT, 'product' ) ) {
		continue;
	}
	$ulap_is_var = 'variable' === $ulap_p['type'];
	$ulap_prod   = $ulap_is_var ? new WC_Product_Variable() : new WC_Product_Simple();
	$ulap_prod->set_name( $ulap_p['name'] );
	$ulap_prod->set_slug( $ulap_p['slug'] );
	$ulap_prod->set_status( 'publish' );
	$ulap_prod->set_short_description( $ulap_p['short'] );
	$ulap_prod->set_description( $ulap_html( $ulap_p['desc'] ) );
	$ulap_prod->set_category_ids( array( $ulap_cat_ids[ $ulap_p['category'] ] ) );
	$ulap_prod->set_featured( ! empty( $ulap_p['featured'] ) );
	$ulap_prod->set_sku( 'ULP-' . strtoupper( strtok( $ulap_p['slug'], '-' ) ) );
	$ulap_prod->set_reviews_allowed( false );

	$ulap_prod->set_image_id( ulap_import_image( $ulap_p['slug'] . '.jpg', $ulap_p['name'] . ' by Ulap Coffee Roasters' ) );
	if ( $ulap_is_var ) {
		$ulap_prod->set_gallery_image_ids( array_filter( array( ulap_import_image( $ulap_p['slug'] . '-card.jpg', 'Tasting card for ' . $ulap_p['name'] ) ) ) );
	}

	$ulap_attrs = array();
	if ( $ulap_is_var ) {
		$ulap_attrs[] = $ulap_attribute( 'size', wp_list_pluck( $ulap_data['sizes'], 'name' ), true, true );
		$ulap_attrs[] = $ulap_attribute( 'grind', $ulap_data['grinds'], true, true );
	}
	if ( ! empty( $ulap_p['roast'] ) ) {
		if ( 'Blends' !== $ulap_p['category'] ) {
			$ulap_attrs[] = $ulap_attribute( 'origin', $ulap_p['origin'] );
		}
		$ulap_attrs[] = $ulap_attribute( 'roast', $ulap_p['roast'] );
		$ulap_attrs[] = $ulap_attribute( 'process', array_map( 'trim', explode( '&', $ulap_p['process'] ) ) );
		$ulap_attrs[] = $ulap_attribute( 'Tasting notes', $ulap_p['notes'], true, false, false );
		$ulap_attrs[] = $ulap_attribute( 'Farm', $ulap_p['farm'], true, false, false );
		$ulap_attrs[] = $ulap_attribute( 'Altitude', number_format( $ulap_p['altitude'] ) . ' masl', true, false, false );
		$ulap_attrs[] = $ulap_attribute( 'Variety', $ulap_p['variety'], true, false, false );
	}
	if ( ! empty( $ulap_p['weight'] ) ) {
		$ulap_attrs[] = $ulap_attribute( 'Contents', $ulap_p['weight'], true, false, false );
	}
	$ulap_prod->set_attributes( $ulap_attrs );

	if ( $ulap_is_var ) {
		$ulap_prod->set_default_attributes(
			array(
				'pa_size'  => $ulap_term_slug( 'pa_size', $ulap_data['sizes'][0]['name'] ),
				'pa_grind' => $ulap_term_slug( 'pa_grind', $ulap_data['grinds'][0] ),
			)
		);
		$ulap_id = $ulap_prod->save();

		// One variation per size; grind is "any", so it never changes the price.
		foreach ( $ulap_data['sizes'] as $ulap_size ) {
			$ulap_var = new WC_Product_Variation();
			$ulap_var->set_parent_id( $ulap_id );
			$ulap_var->set_attributes(
				array(
					'pa_size'  => $ulap_term_slug( 'pa_size', $ulap_size['name'] ),
					'pa_grind' => '',
				)
			);
			$ulap_var->set_regular_price( (string) ( round( $ulap_p['price'] * $ulap_size['factor'] / 10 ) * 10 ) );
			$ulap_var->set_sku( $ulap_prod->get_sku() . '-' . strtoupper( str_replace( ' ', '', $ulap_size['name'] ) ) );
			$ulap_var->set_weight( (string) ( (float) $ulap_size['name'] >= 250 ? (float) $ulap_size['name'] / 1000 : (float) $ulap_size['name'] ) );
			$ulap_var->set_stock_status( in_array( $ulap_size['name'], $ulap_p['soldout'] ?? array(), true ) ? 'outofstock' : 'instock' );
			$ulap_var->save();
		}
		WC_Product_Variable::sync( $ulap_id );
	} else {
		$ulap_prod->set_regular_price( (string) $ulap_p['price'] );
		if ( ! empty( $ulap_p['sale'] ) ) {
			$ulap_prod->set_sale_price( (string) $ulap_p['sale'] );
		}
		$ulap_prod->save();
	}
}

/*
 * ---- Shipping: Metro Manila, the rest of Luzon, and everywhere else (Visayas and Mindanao)
 */
$ulap_luzon = array( 'ABR', 'ALB', 'APA', 'AUR', 'BAN', 'BTN', 'BTG', 'BEN', 'BUL', 'CAG', 'CAN', 'CAS', 'CAT', 'CAV', 'IFU', 'ILN', 'ILS', 'ISA', 'KAL', 'LUN', 'LAG', 'MAD', 'MAS', 'MOU', 'NUE', 'NUV', 'MDC', 'MDR', 'PLW', 'PAM', 'PAN', 'QUE', 'QUI', 'RIZ', 'ROM', 'SOR', 'TAR', 'ZMB' );
$ulap_zones = array(
	array( 'Metro Manila', array( 'PH:00' ), 99, 'Next-day delivery' ),
	array( 'Luzon', array_map( fn( $c ) => 'PH:' . $c, $ulap_luzon ), 149, '2 to 3 days' ),
);
foreach ( $ulap_zones as $ulap_order => $ulap_z ) {
	$ulap_zone = new WC_Shipping_Zone();
	$ulap_zone->set_zone_name( $ulap_z[0] );
	$ulap_zone->set_zone_order( $ulap_order );
	foreach ( $ulap_z[1] as $ulap_loc ) {
		$ulap_zone->add_location( $ulap_loc, 'state' );
	}
	$ulap_zone->save();
	ulap_add_rates( $ulap_zone, $ulap_z[2], $ulap_z[3] );
}
ulap_add_rates( new WC_Shipping_Zone( 0 ), 199, '3 to 5 days' ); // Visayas and Mindanao.

/**
 * Flat rate plus free shipping over ₱1,500 for a zone.
 *
 * @param WC_Shipping_Zone $zone  Zone.
 * @param int              $cost  Flat rate in PHP.
 * @param string           $title Delivery estimate shown at checkout.
 */
function ulap_add_rates( $zone, $cost, $title ) {
	$flat = $zone->add_shipping_method( 'flat_rate' );
	update_option(
		"woocommerce_flat_rate_{$flat}_settings",
		array(
			'title'      => 'Standard · ' . $title,
			'tax_status' => 'none',
			'cost'       => (string) $cost,
		)
	);
	$free = $zone->add_shipping_method( 'free_shipping' );
	update_option(
		"woocommerce_free_shipping_{$free}_settings",
		array(
			'title'      => 'Free shipping · ' . $title,
			'requires'   => 'min_amount',
			'min_amount' => '1500',
		)
	);
}

/*
 * ---- Transfer Pay: demo accounts. The numbers and QR codes are placeholders.
 */
$ulap_wallets = array(
	'gcash' => array( 'GCash', '0900 000 4827', '' ),
	'maya'  => array( 'Maya', '0900 000 4827', '' ),
	'bank'  => array( 'Bank transfer', '0000 1234 5678', 'BPI · Session Road branch' ),
);
foreach ( $ulap_wallets as $ulap_key => $ulap_w ) {
	$ulap_settings = array_merge(
		(array) get_option( "woocommerce_tp_{$ulap_key}_settings", array() ),
		array(
			'enabled'        => 'yes',
			'title'          => $ulap_w[0],
			'account_name'   => 'Ulap Coffee Roasters',
			'account_number' => $ulap_w[1],
			'qr_image'       => wp_get_attachment_url( ulap_import_image( "qr-{$ulap_key}.jpg", "{$ulap_w[0]} QR code for Ulap Coffee Roasters (demo)" ) ),
			'expire_hours'   => '48',
		)
	);
	if ( $ulap_w[2] ) {
		$ulap_settings['bank_name'] = $ulap_w[2];
	}
	update_option( "woocommerce_tp_{$ulap_key}_settings", $ulap_settings );
}

/*
 * ---- Pages
 */
require __DIR__ . '/pages.php';
foreach ( ulap_pages( $ulap_data ) as $ulap_slug => $ulap_page ) {
	if ( get_page_by_path( $ulap_slug ) ) {
		continue;
	}
	wp_insert_post(
		array(
			'post_type'     => 'page',
			'post_status'   => 'publish',
			'post_name'     => $ulap_slug,
			'post_title'    => $ulap_page['title'],
			'post_content'  => $ulap_page['content'],
			'page_template' => $ulap_page['template'] ?? '',
		)
	);
}
$ulap_home = get_page_by_path( 'home' );
if ( $ulap_home ) {
	update_option( 'show_on_front', 'page' );
	update_option( 'page_on_front', $ulap_home->ID );
}

// The default post and page that ship with WordPress don't belong in a shop.
foreach ( array( 'hello-world' => 'post', 'sample-page' => 'page' ) as $ulap_slug => $ulap_type ) {
	$ulap_post = get_page_by_path( $ulap_slug, OBJECT, $ulap_type );
	if ( $ulap_post ) {
		wp_delete_post( $ulap_post->ID, true );
	}
}

/*
 * ---- Sample orders so wp-admin shows every step of the transfer flow
 */
require __DIR__ . '/orders.php';

echo "Ulap store ready.\n";
