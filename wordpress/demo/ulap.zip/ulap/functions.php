<?php
/**
 * Ulap: a WooCommerce block theme for a Philippine coffee roaster.
 *
 * Design lives in theme.json; templates and patterns are plain block markup.
 * This file only wires up what theme.json can't: assets, block styles,
 * pattern helpers and a few WooCommerce defaults.
 *
 * @package Ulap
 */

defined( 'ABSPATH' ) || exit;

define( 'ULAP_VERSION', '1.0.0' );

add_action(
	'after_setup_theme',
	function () {
		load_theme_textdomain( 'ulap', get_template_directory() . '/languages' );
		add_theme_support( 'wc-product-gallery-zoom' );
		add_theme_support( 'wc-product-gallery-lightbox' );
		add_theme_support( 'wc-product-gallery-slider' );
		add_editor_style( 'style.css' );
	}
);

add_action(
	'wp_enqueue_scripts',
	function () {
		wp_enqueue_style( 'ulap', get_stylesheet_uri(), array(), ULAP_VERSION );
	}
);

/**
 * Preload the display face. Every headline above the fold is set in it, so
 * fetching it early keeps the hero from swapping fonts mid-paint.
 */
add_action(
	'wp_head',
	function () {
		printf(
			'<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n",
			esc_url( get_theme_file_uri( 'assets/fonts/fraunces.woff2' ) )
		);
	},
	1
);

add_action(
	'init',
	function () {
		register_block_pattern_category( 'ulap', array( 'label' => __( 'Ulap', 'ulap' ) ) );

		register_block_style(
			'core/group',
			array(
				'name'  => 'card',
				'label' => __( 'Card', 'ulap' ),
			)
		);
		register_block_style(
			'core/paragraph',
			array(
				'name'  => 'eyebrow',
				'label' => __( 'Eyebrow', 'ulap' ),
			)
		);
		register_block_style(
			'core/list',
			array(
				'name'  => 'checks',
				'label' => __( 'Checks', 'ulap' ),
			)
		);
	}
);

/**
 * URL of a page by its path, falling back to home_url().
 *
 * Header, footer and front-page patterns are PHP precisely so their links
 * follow the site's real permalinks, including WordPress Playground's
 * scoped URLs, instead of hard-coded paths.
 *
 * @param string $path Page path, e.g. 'brew-guide'.
 * @return string
 */
function ulap_link( $path ) {
	$page = get_page_by_path( trim( $path, '/' ) );
	return $page ? get_permalink( $page ) : home_url( '/' . trim( $path, '/' ) . '/' );
}

/**
 * Shop URL, optionally narrowed to a category or filtered by attributes.
 *
 * @param string $category Product category slug, or '' for the whole shop.
 * @param array  $filters  e.g. array( 'roast' => 'light' ) → ?filter_roast=light.
 * @return string
 */
function ulap_shop_link( $category = '', $filters = array() ) {
	$url = '';
	if ( $category ) {
		$term = get_term_by( 'slug', $category, 'product_cat' );
		$url  = $term ? get_term_link( $term ) : '';
	}
	if ( ! $url || is_wp_error( $url ) ) {
		$url = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/shop/' );
	}
	foreach ( $filters as $attribute => $value ) {
		$url = add_query_arg( 'filter_' . $attribute, rawurlencode( $value ), $url );
	}
	return $url;
}

/**
 * A navigation-link block comment with safely encoded attributes.
 *
 * @param string $label Link text.
 * @param string $url   Destination.
 * @return string Serialized block.
 */
function ulap_nav_link( $label, $url ) {
	return '<!-- wp:navigation-link ' . wp_json_encode(
		array(
			'label' => $label,
			'url'   => $url,
			'kind'  => 'custom',
		),
		JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP
	) . ' /-->';
}

/*
 * WooCommerce hooks its account and mini-cart blocks in after every header
 * navigation. The Ulap header places its own, so skip the duplicates.
 */
add_filter(
	'hooked_block_types',
	function ( $hooked, $position, $anchor ) {
		if ( 'core/navigation' === $anchor ) {
			$hooked = array_values( array_diff( $hooked, array( 'woocommerce/customer-account', 'woocommerce/mini-cart' ) ) );
		}
		return $hooked;
	},
	20,
	3
);

// WooCommerce defaults that suit a small-batch roaster.
add_filter( 'woocommerce_sale_flash', fn() => '<span class="onsale">' . esc_html__( 'Sale', 'ulap' ) . '</span>' );
add_filter( 'loop_shop_per_page', fn() => 12 );
