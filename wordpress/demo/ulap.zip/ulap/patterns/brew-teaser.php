<?php
/**
 * Title: Brew calculator section
 * Slug: ulap/brew-teaser
 * Categories: ulap, featured
 * Description: Heading and the interactive brew calculator from the Ulap Blocks plugin.
 *
 * @package Ulap
 */

?>
<!-- wp:group {"align":"wide","className":"ulap-brew-section","style":{"spacing":{"margin":{"top":"var:preset|spacing|70"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group alignwide ulap-brew-section" style="margin-top:var(--wp--preset--spacing--70)">
<!-- wp:group {"className":"ulap-section__head","layout":{"type":"flex","justifyContent":"space-between","verticalAlignment":"bottom","flexWrap":"wrap"}} -->
<div class="wp-block-group ulap-section__head">
<!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group">
<!-- wp:paragraph {"className":"is-style-eyebrow"} -->
<p class="is-style-eyebrow"><?php esc_html_e( 'Brew guide', 'ulap' ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:heading {"fontSize":"xx-large"} -->
<h2 class="wp-block-heading has-xx-large-font-size"><?php esc_html_e( 'Dial in your cup.', 'ulap' ); ?></h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->
<!-- wp:paragraph {"className":"ulap-arrow-link"} -->
<p class="ulap-arrow-link"><a href="<?php echo esc_url( ulap_link( 'brew-guide' ) ); ?>"><?php esc_html_e( 'Full brew guide', 'ulap' ); ?></a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:ulap/brew-calculator /-->
</div>
<!-- /wp:group -->
