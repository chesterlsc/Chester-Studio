<?php
/**
 * Title: Footer
 * Slug: ulap/footer
 * Categories: footer
 * Block Types: core/template-part/footer
 * Inserter: no
 *
 * @package Ulap
 */

$ulap_cols = array(
	__( 'Shop', 'ulap' )  => array(
		__( 'All coffee', 'ulap' )    => ulap_shop_link(),
		__( 'Single origin', 'ulap' ) => ulap_shop_link( 'single-origin' ),
		__( 'Blends', 'ulap' )        => ulap_shop_link( 'blends' ),
		__( 'Drip bags', 'ulap' )     => ulap_shop_link( 'drip-bags' ),
		__( 'Brew gear', 'ulap' )     => ulap_shop_link( 'brew-gear' ),
	),
	__( 'Learn', 'ulap' ) => array(
		__( 'Origins', 'ulap' )    => ulap_link( 'origins' ),
		__( 'Brew guide', 'ulap' ) => ulap_link( 'brew-guide' ),
		__( 'Our story', 'ulap' )  => ulap_link( 'our-story' ),
	),
	__( 'Help', 'ulap' )  => array(
		__( 'Shipping & FAQ', 'ulap' ) => ulap_link( 'shipping-faq' ),
		__( 'My account', 'ulap' )     => function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : ulap_link( 'my-account' ),
		__( 'Cart', 'ulap' )           => function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : ulap_link( 'cart' ),
	),
);
?>
<!-- wp:group {"tagName":"footer","className":"ulap-footer","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|50"},"margin":{"top":"var:preset|spacing|80"}}},"backgroundColor":"contrast","textColor":"base","layout":{"type":"constrained"}} -->
<footer class="wp-block-group ulap-footer has-base-color has-contrast-background-color has-text-color has-background" style="margin-top:var(--wp--preset--spacing--80);padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--50)">
<!-- wp:columns {"align":"wide","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns alignwide">
<!-- wp:column {"width":"40%"} -->
<div class="wp-block-column" style="flex-basis:40%">
<!-- wp:site-title {"level":0,"className":"ulap-wordmark"} /-->
<!-- wp:paragraph {"className":"ulap-footer__lede","fontSize":"large","fontFamily":"display"} -->
<p class="ulap-footer__lede has-display-font-family has-large-font-size"><?php esc_html_e( 'Coffee from the mountains, roasted twice a week and shipped within 48 hours.', 'ulap' ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"ulap-pay-chips","fontSize":"x-small"} -->
<p class="ulap-pay-chips has-x-small-font-size"><span>GCash</span><span>Maya</span><span><?php esc_html_e( 'Bank transfer', 'ulap' ); ?></span></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->
<?php foreach ( $ulap_cols as $ulap_heading => $ulap_links ) : ?>
<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:heading {"level":2,"className":"ulap-footer__h","fontSize":"x-small"} -->
<h2 class="wp-block-heading ulap-footer__h has-x-small-font-size"><?php echo esc_html( $ulap_heading ); ?></h2>
<!-- /wp:heading -->
<!-- wp:list {"className":"ulap-footer__list"} -->
<ul class="wp-block-list ulap-footer__list">
<?php foreach ( $ulap_links as $ulap_label => $ulap_url ) : ?>
<!-- wp:list-item -->
<li><a href="<?php echo esc_url( $ulap_url ); ?>"><?php echo esc_html( $ulap_label ); ?></a></li>
<!-- /wp:list-item -->
<?php endforeach; ?>
</ul>
<!-- /wp:list -->
</div>
<!-- /wp:column -->
<?php endforeach; ?>
</div>
<!-- /wp:columns -->

<!-- wp:group {"align":"wide","className":"ulap-footer__base","style":{"spacing":{"margin":{"top":"var:preset|spacing|70"}}},"layout":{"type":"flex","justifyContent":"space-between","flexWrap":"wrap"}} -->
<div class="wp-block-group alignwide ulap-footer__base" style="margin-top:var(--wp--preset--spacing--70)">
<!-- wp:paragraph {"fontSize":"x-small"} -->
<p class="has-x-small-font-size">© <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php esc_html_e( 'Ulap Coffee Roasters, Baguio City', 'ulap' ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"fontSize":"x-small"} -->
<p class="has-x-small-font-size"><?php
	printf(
		/* translators: %s: link to Chester Studio */
		esc_html__( 'A concept store. Theme and plugins designed and built by %s.', 'ulap' ),
		'<a href="https://chesterstudio.space/wordpress/">Chester Studio</a>'
	);
	?></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</footer>
<!-- /wp:group -->
