<?php
/**
 * Title: Header
 * Slug: ulap/header
 * Categories: header
 * Block Types: core/template-part/header
 * Inserter: no
 *
 * @package Ulap
 */

?>
<!-- wp:group {"className":"ulap-announce","style":{"spacing":{"padding":{"top":"0.55rem","bottom":"0.55rem"}}},"backgroundColor":"contrast","textColor":"base-2","layout":{"type":"constrained"}} -->
<div class="wp-block-group ulap-announce has-base-2-color has-contrast-background-color has-text-color has-background" style="padding-top:0.55rem;padding-bottom:0.55rem">
<!-- wp:paragraph {"align":"center","fontSize":"x-small"} -->
<p class="has-text-align-center has-x-small-font-size"><?php esc_html_e( 'Roasted every Tuesday and Friday in Baguio · Free shipping nationwide on orders over ₱1,500', 'ulap' ); ?></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"ulap-header","layout":{"type":"constrained"}} -->
<div class="wp-block-group ulap-header">
<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"1rem","bottom":"1rem"}}},"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group alignwide" style="padding-top:1rem;padding-bottom:1rem">
<!-- wp:site-title {"level":0,"className":"ulap-wordmark"} /-->

<!-- wp:navigation {"overlayMenu":"mobile","className":"ulap-nav","layout":{"type":"flex","justifyContent":"center"},"style":{"spacing":{"blockGap":"2rem"}}} -->
<?php
echo ulap_nav_link( __( 'Shop', 'ulap' ), ulap_shop_link() ); // phpcs:ignore WordPress.Security.EscapeOutput -- serialized block, encoded by wp_json_encode.
echo ulap_nav_link( __( 'Single origin', 'ulap' ), ulap_shop_link( 'single-origin' ) ); // phpcs:ignore WordPress.Security.EscapeOutput
echo ulap_nav_link( __( 'Origins', 'ulap' ), ulap_link( 'origins' ) ); // phpcs:ignore WordPress.Security.EscapeOutput
echo ulap_nav_link( __( 'Brew guide', 'ulap' ), ulap_link( 'brew-guide' ) ); // phpcs:ignore WordPress.Security.EscapeOutput
echo ulap_nav_link( __( 'Our story', 'ulap' ), ulap_link( 'our-story' ) ); // phpcs:ignore WordPress.Security.EscapeOutput
?>
<!-- /wp:navigation -->

<!-- wp:group {"className":"ulap-tools","style":{"spacing":{"blockGap":"0.35rem"}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group ulap-tools">
<!-- wp:search {"label":"<?php echo esc_attr__( 'Search', 'ulap' ); ?>","showLabel":false,"placeholder":"<?php echo esc_attr__( 'Search coffee', 'ulap' ); ?>","buttonText":"<?php echo esc_attr__( 'Search', 'ulap' ); ?>","buttonPosition":"button-only","buttonUseIcon":true,"isSearchFieldHidden":true,"query":{"post_type":"product"}} /-->
<!-- wp:woocommerce/customer-account {"displayStyle":"icon_only","iconStyle":"line","iconClass":"wc-block-customer-account__account-icon"} /-->
<!-- wp:woocommerce/mini-cart {"addToCartBehaviour":"open_drawer"} /-->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
