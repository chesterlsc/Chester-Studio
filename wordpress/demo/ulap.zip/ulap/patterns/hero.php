<?php
/**
 * Title: Hero: grown above the clouds
 * Slug: ulap/hero
 * Categories: ulap, banner
 * Description: Headline, two calls to action and the next roast date, beside the three-bag illustration.
 *
 * @package Ulap
 */

// Batches roast on Tuesday and Friday; orders close at 6 PM the day before.
$ulap_tz    = wp_timezone();
$ulap_now   = new DateTimeImmutable( 'now', $ulap_tz );
$ulap_roast = null;
foreach ( array( 'tuesday', 'friday' ) as $ulap_day ) {
	$ulap_candidate = new DateTimeImmutable( 'today ' . $ulap_day, $ulap_tz );
	if ( $ulap_now >= $ulap_candidate->modify( '-1 day 18:00' ) ) {
		$ulap_candidate = $ulap_candidate->modify( '+1 week' );
	}
	if ( ! $ulap_roast || $ulap_candidate < $ulap_roast ) {
		$ulap_roast = $ulap_candidate;
	}
}
$ulap_cutoff = $ulap_roast->modify( '-1 day' );
?>
<!-- wp:group {"align":"full","className":"ulap-hero","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull ulap-hero" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60)">
<!-- wp:columns {"verticalAlignment":"center","align":"wide","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|70"}}}} -->
<div class="wp-block-columns alignwide are-vertically-aligned-center">
<!-- wp:column {"verticalAlignment":"center","width":"52%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:52%">
<!-- wp:paragraph {"className":"is-style-eyebrow"} -->
<p class="is-style-eyebrow"><?php esc_html_e( 'Small-lot Philippine coffee', 'ulap' ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":1,"className":"ulap-hero__title","fontSize":"display"} -->
<h1 class="wp-block-heading ulap-hero__title has-display-font-size"><?php echo wp_kses( __( 'Grown above <em>the clouds.</em>', 'ulap' ), array( 'em' => array() ) ); ?></h1>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"ulap-hero__lede","fontSize":"large"} -->
<p class="ulap-hero__lede has-large-font-size"><?php esc_html_e( 'Arabica, Liberica and Excelsa from eight farms across Luzon and Mindanao, roasted in small batches in Baguio and at your door within days.', 'ulap' ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|40"}}}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--40)">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( ulap_shop_link() ); ?>"><?php esc_html_e( 'Shop the coffee', 'ulap' ); ?></a></div>
<!-- /wp:button -->
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="#find-your-roast"><?php esc_html_e( 'Find your roast', 'ulap' ); ?></a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
<!-- wp:paragraph {"className":"ulap-next-roast","fontSize":"small"} -->
<p class="ulap-next-roast has-small-font-size"><span class="ulap-dot" aria-hidden="true"></span><span><?php
	printf(
		/* translators: 1: roast day and date, 2: order cut-off day */
		esc_html__( 'Next roast %1$s. Order by %2$s, 6 PM.', 'ulap' ),
		'<strong>' . esc_html( wp_date( 'l, j F', $ulap_roast->getTimestamp() ) ) . '</strong>',
		esc_html( wp_date( 'l', $ulap_cutoff->getTimestamp() ) )
	);
	?></span></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center">
<!-- wp:image {"width":"1200px","sizeSlug":"full","linkDestination":"none","className":"ulap-hero__art"} -->
<figure class="wp-block-image size-full is-resized ulap-hero__art"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/hero.jpg' ) ); ?>" alt="<?php esc_attr_e( 'Three Ulap coffee bags, Atok Highlands, House Blend and Batangas Barako, standing on a green ridge below the clouds', 'ulap' ); ?>" width="1200" height="1440" fetchpriority="high" style="width:1200px"/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->
</div>
<!-- /wp:group -->
