<?php
/**
 * Title: How paying by GCash, Maya or bank works
 * Slug: ulap/how-to-pay
 * Categories: ulap, featured
 * Description: Three steps for paying by transfer, written for shoppers who have never done it online.
 *
 * @package Ulap
 */

$ulap_steps = array(
	array( __( 'Check out', 'ulap' ), __( 'Choose GCash, Maya or bank transfer. Your order is held for 48 hours.', 'ulap' ) ),
	array( __( 'Send the exact amount', 'ulap' ), __( 'Scan the QR or copy the number, and put your order number in the message.', 'ulap' ) ),
	array( __( 'Upload your receipt', 'ulap' ), __( 'Drop the screenshot on your order page. We confirm it the same day and roast your beans.', 'ulap' ) ),
);
?>
<!-- wp:group {"align":"wide","className":"ulap-pay","style":{"spacing":{"margin":{"top":"var:preset|spacing|70"},"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60","left":"var:preset|spacing|60","right":"var:preset|spacing|60"}},"border":{"radius":"var:custom|radius|large"}},"backgroundColor":"accent-2","textColor":"base-2","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide ulap-pay has-base-2-color has-accent-2-background-color has-text-color has-background" style="border-radius:var(--wp--custom--radius--large);margin-top:var(--wp--preset--spacing--70);padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--60)">
<!-- wp:paragraph {"className":"is-style-eyebrow"} -->
<p class="is-style-eyebrow"><?php esc_html_e( 'GCash · Maya · Bank transfer', 'ulap' ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:heading {"textColor":"base-2","fontSize":"xx-large"} -->
<h2 class="wp-block-heading has-base-2-color has-text-color has-xx-large-font-size"><?php esc_html_e( 'Pay the way you already do.', 'ulap' ); ?></h2>
<!-- /wp:heading -->
<!-- wp:list {"ordered":true,"className":"ulap-pay__steps"} -->
<ol class="wp-block-list ulap-pay__steps">
<?php foreach ( $ulap_steps as $ulap_step ) : ?>
<!-- wp:list-item -->
<li><strong><?php echo esc_html( $ulap_step[0] ); ?></strong><span><?php echo esc_html( $ulap_step[1] ); ?></span></li>
<!-- /wp:list-item -->
<?php endforeach; ?>
</ol>
<!-- /wp:list -->
</div>
<!-- /wp:group -->
