<?php
/**
 * Title: Origins altitude chart
 * Slug: ulap/origins-chart
 * Categories: ulap, featured
 * Description: Every single-origin farm drawn as a peak at its real altitude, with the cloud line.
 *
 * @package Ulap
 */

?>
<!-- wp:group {"align":"wide","className":"ulap-origins","style":{"spacing":{"margin":{"top":"var:preset|spacing|70"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group alignwide ulap-origins" style="margin-top:var(--wp--preset--spacing--70)">
<!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns">
<!-- wp:column {"width":"38%"} -->
<div class="wp-block-column" style="flex-basis:38%">
<!-- wp:paragraph {"className":"is-style-eyebrow"} -->
<p class="is-style-eyebrow"><?php esc_html_e( 'Where it grows', 'ulap' ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:heading {"fontSize":"xx-large"} -->
<h2 class="wp-block-heading has-xx-large-font-size"><?php esc_html_e( 'Eight farms, from the cloud line to the coast.', 'ulap' ); ?></h2>
<!-- /wp:heading -->
</div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"bottom"} -->
<div class="wp-block-column is-vertically-aligned-bottom">
<!-- wp:paragraph {"textColor":"contrast-2"} -->
<p class="has-contrast-2-color has-text-color"><?php esc_html_e( 'Above about 1,000 metres the Cordillera and Mindanao highlands sit in cloud most afternoons. The cool slows the cherries down and the cup gets sweeter and brighter. Below it, Batangas and Cavite grow the big, bold Liberica and Excelsa that Filipinos grew up on.', 'ulap' ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"ulap-arrow-link"} -->
<p class="ulap-arrow-link"><a href="<?php echo esc_url( ulap_link( 'origins' ) ); ?>"><?php esc_html_e( 'Meet the farms', 'ulap' ); ?></a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->
<!-- wp:html -->
<figure class="ulap-origins__chart"><?php
	// Inline so the chart's labels use the theme's fonts; the SVG carries its own title and description.
	echo file_get_contents( get_theme_file_path( 'assets/img/altitude.svg' ) ); // phpcs:ignore WordPress.Security.EscapeOutput,WordPress.WP.AlternativeFunctions -- trusted theme asset.
?></figure>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
