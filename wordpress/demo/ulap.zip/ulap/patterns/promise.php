<?php
/**
 * Title: Promise row: roast, ship, pay
 * Slug: ulap/promise
 * Categories: ulap, featured
 * Description: Three short promises about freshness, delivery and payment.
 *
 * @package Ulap
 */

$ulap_promises = array(
	'roast' => array( __( 'Roasted to order', 'ulap' ), __( 'Tuesday and Friday batches, so beans reach you two to five days off roast.', 'ulap' ) ),
	'ship'  => array( __( 'Shipped nationwide', 'ulap' ), __( 'Metro Manila next day, Luzon in two to three days, Visayas and Mindanao in three to five.', 'ulap' ) ),
	'pay'   => array( __( 'Pay your way', 'ulap' ), __( 'GCash, Maya or bank transfer. Upload your receipt and we confirm it the same day.', 'ulap' ) ),
);
?>
<!-- wp:group {"align":"wide","className":"ulap-promise","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"layout":{"type":"grid","minimumColumnWidth":"16rem"}} -->
<div class="wp-block-group alignwide ulap-promise" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)">
<?php foreach ( $ulap_promises as $ulap_key => $ulap_promise ) : ?>
<!-- wp:group {"className":"ulap-promise__item ulap-promise__item--<?php echo esc_attr( $ulap_key ); ?>","layout":{"type":"default"}} -->
<div class="wp-block-group ulap-promise__item ulap-promise__item--<?php echo esc_attr( $ulap_key ); ?>">
<!-- wp:heading {"level":3,"fontSize":"medium"} -->
<h3 class="wp-block-heading has-medium-font-size"><?php echo esc_html( $ulap_promise[0] ); ?></h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"contrast-2","fontSize":"small"} -->
<p class="has-contrast-2-color has-text-color has-small-font-size"><?php echo esc_html( $ulap_promise[1] ); ?></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<?php endforeach; ?>
</div>
<!-- /wp:group -->
