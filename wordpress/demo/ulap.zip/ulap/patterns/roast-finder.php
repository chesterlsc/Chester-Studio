<?php
/**
 * Title: Find your roast
 * Slug: ulap/roast-finder
 * Categories: ulap, woo-commerce
 * Description: The roast spectrum from light to dark, each step linking to the filtered shop.
 *
 * @package Ulap
 */

$ulap_roasts = array(
	'light'        => array( __( 'Light', 'ulap' ), __( 'Bright, floral, tea-like. Best as pour-over.', 'ulap' ), '#b27c4e' ),
	'medium-light' => array( __( 'Medium-light', 'ulap' ), __( 'Fruit-forward and sweet, with more body.', 'ulap' ), '#96603a' ),
	'medium'       => array( __( 'Medium', 'ulap' ), __( 'Balanced and easy. Good in anything.', 'ulap' ), '#7a4a2c' ),
	'medium-dark'  => array( __( 'Medium-dark', 'ulap' ), __( 'Chocolate and caramel. Made for milk.', 'ulap' ), '#5a3420' ),
	'dark'         => array( __( 'Dark', 'ulap' ), __( 'Smoky and bold. The barako way.', 'ulap' ), '#3a2216' ),
);
?>
<!-- wp:group {"anchor":"find-your-roast","align":"full","className":"ulap-roasts","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"},"margin":{"top":"var:preset|spacing|70"}}},"backgroundColor":"surface","layout":{"type":"constrained"}} -->
<div id="find-your-roast" class="wp-block-group alignfull ulap-roasts has-surface-background-color has-background" style="margin-top:var(--wp--preset--spacing--70);padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)">
<!-- wp:group {"align":"wide","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide">
<!-- wp:paragraph {"className":"is-style-eyebrow"} -->
<p class="is-style-eyebrow"><?php esc_html_e( 'Find your roast', 'ulap' ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:heading {"className":"ulap-roasts__title","fontSize":"xx-large"} -->
<h2 class="wp-block-heading ulap-roasts__title has-xx-large-font-size"><?php esc_html_e( 'From bright and floral to bold and smoky.', 'ulap' ); ?></h2>
<!-- /wp:heading -->
<!-- wp:list {"className":"ulap-roasts__list"} -->
<ul class="wp-block-list ulap-roasts__list">
<?php foreach ( $ulap_roasts as $ulap_slug => $ulap_roast ) : ?>
<!-- wp:list-item -->
<li style="--bean:<?php echo esc_attr( $ulap_roast[2] ); ?>"><a href="<?php echo esc_url( ulap_shop_link( '', array( 'roast' => $ulap_slug ) ) ); ?>"><strong><?php echo esc_html( $ulap_roast[0] ); ?></strong><span><?php echo esc_html( $ulap_roast[1] ); ?></span></a></li>
<!-- /wp:list-item -->
<?php endforeach; ?>
</ul>
<!-- /wp:list -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
