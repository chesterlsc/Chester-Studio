<?php
/**
 * Title: Shop filters
 * Slug: ulap/shop-filters
 * Categories: ulap, woo-commerce
 * Inserter: no
 * Description: Category, roast, process and origin filters for the shop sidebar.
 *
 * PHP so the attribute filters point at this site's real attribute IDs.
 *
 * @package Ulap
 */

$ulap_filters = array();
if ( function_exists( 'wc_attribute_taxonomy_id_by_name' ) ) {
	foreach ( array(
		'roast'   => __( 'Roast', 'ulap' ),
		'process' => __( 'Process', 'ulap' ),
		'origin'  => __( 'Origin', 'ulap' ),
	) as $ulap_slug => $ulap_label ) {
		$ulap_id = wc_attribute_taxonomy_id_by_name( $ulap_slug );
		if ( $ulap_id ) {
			$ulap_filters[ $ulap_id ] = $ulap_label;
		}
	}
}
?>
<!-- wp:woocommerce/product-filters {"className":"ulap-filters"} -->
<div class="wp-block-woocommerce-product-filters ulap-filters">
<!-- wp:woocommerce/product-filter-active -->
<div class="wp-block-woocommerce-product-filter-active">
<!-- wp:woocommerce/product-filter-removable-chips /-->
<!-- wp:woocommerce/product-filter-clear-button -->
<!-- wp:buttons {"layout":{"type":"flex"}} -->
<div class="wp-block-buttons"><!-- wp:button {"className":"wc-block-product-filter-clear-button is-style-outline","style":{"typography":{"fontSize":"0.8rem"}}} -->
<div class="wp-block-button wc-block-product-filter-clear-button is-style-outline"><a class="wp-block-button__link wp-element-button" style="font-size:0.8rem"><?php esc_html_e( 'Clear filters', 'ulap' ); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->
<!-- /wp:woocommerce/product-filter-clear-button -->
</div>
<!-- /wp:woocommerce/product-filter-active -->

<!-- wp:woocommerce/product-filter-taxonomy {"taxonomy":"product_cat"} -->
<div class="wp-block-woocommerce-product-filter-taxonomy">
<!-- wp:heading {"level":3,"className":"ulap-filters__h"} -->
<h3 class="wp-block-heading ulap-filters__h"><?php esc_html_e( 'Category', 'ulap' ); ?></h3>
<!-- /wp:heading -->
<!-- wp:woocommerce/product-filter-checkbox-list /-->
</div>
<!-- /wp:woocommerce/product-filter-taxonomy -->

<?php foreach ( $ulap_filters as $ulap_id => $ulap_label ) : ?>
<!-- wp:woocommerce/product-filter-attribute {"attributeId":<?php echo (int) $ulap_id; ?>,"showCounts":true} -->
<div class="wp-block-woocommerce-product-filter-attribute">
<!-- wp:heading {"level":3,"className":"ulap-filters__h"} -->
<h3 class="wp-block-heading ulap-filters__h"><?php echo esc_html( $ulap_label ); ?></h3>
<!-- /wp:heading -->
<!-- wp:woocommerce/product-filter-checkbox-list /-->
</div>
<!-- /wp:woocommerce/product-filter-attribute -->
<?php endforeach; ?>

<!-- wp:woocommerce/product-filter-price -->
<div class="wp-block-woocommerce-product-filter-price">
<!-- wp:heading {"level":3,"className":"ulap-filters__h"} -->
<h3 class="wp-block-heading ulap-filters__h"><?php esc_html_e( 'Price', 'ulap' ); ?></h3>
<!-- /wp:heading -->
<!-- wp:woocommerce/product-filter-price-slider /-->
</div>
<!-- /wp:woocommerce/product-filter-price -->
</div>
<!-- /wp:woocommerce/product-filters -->
