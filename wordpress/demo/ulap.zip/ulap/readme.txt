=== Ulap ===
Contributors: chesterstudio
Requires at least: 6.6
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A WooCommerce block theme for a Philippine specialty coffee roaster.

== Description ==

Ulap is a Full Site Editing theme built for a small-batch coffee shop on WooCommerce.

* Design tokens in theme.json: an oat, espresso and terracotta palette, Fraunces and Inter (self-hosted, display face preloaded), a fluid type scale and spacing scale.
* Header and footer are PHP patterns, so every link follows the site's own permalinks.
* Homepage patterns: hero with a live "next roast" date, promise row, featured roasts, roast finder, origins altitude chart, brew calculator section and a how-to-pay band.
* WooCommerce block templates for the shop, product categories, attributes, search, single product, cart, checkout and order confirmation.
* Shop sidebar uses WooCommerce's Product Filters blocks with the store's real attribute IDs.
* Block styles: Card (group), Eyebrow (paragraph), Checks (list).
* Pairs with the Ulap Blocks plugin (coffee profile and brew calculator) and Transfer Pay for WooCommerce.

== Changelog ==

= 1.0.0 =
* First release.

== Copyright ==

Ulap, (C) 2026 Chester Studio. Distributed under the terms of the GNU GPL v2 or later.

Fraunces, (C) The Fraunces Project Authors. SIL Open Font License 1.1. https://github.com/undercasetype/Fraunces
Inter, (C) The Inter Project Authors. SIL Open Font License 1.1. https://github.com/rsms/inter

Images in assets/img were drawn for this theme and are released under GPLv2 or later.
